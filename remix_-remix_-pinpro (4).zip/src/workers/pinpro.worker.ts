/* eslint-disable no-restricted-globals */

interface UserPayload {
  taskId: string;
  countryCode: string;
  userGeohash: string; // Ej: "d5nx7" (precisión de ~5km)
  activeFilters: string[];
}

interface Professional {
  id: string;
  name: string;
  country: string;
  geohash: string;
  category: string;
  isAvailable: boolean;
}

self.onmessage = (event: MessageEvent) => {
  const { type, payload, databasePros } = event.data;

  if (type === 'PROCESS_HIGH_TRAFFIC_QUEUE') {
    const startTime = performance.now();
    const { countryCode, userGeohash, activeFilters } = payload as UserPayload;

    // 1. SHARDING: Filtrar de golpe solo los profesionales del país del usuario
    const countryShard = databasePros.filter((pro: Professional) => pro.country === countryCode);

    // 2. GEOHASH MATCHING: Filtrar los que comparten la misma región geográfica (primeros 4 caracteres)
    const geoPrecision = userGeohash.substring(0, 4);
    
    const matchedPros = countryShard.filter((pro: Professional) => {
      // Validación rápida por vecindad de Geohash
      if (!pro.geohash.startsWith(geoPrecision)) return false;

      // Filtros de negocio de la PWA
      if (activeFilters.includes('disponibilidad_inmediata') && !pro.isAvailable) return false;
      if (activeFilters.length > 0 && !activeFilters.includes(pro.category)) return false;

      return true;
    });

    const endTime = performance.now();
    const executionTimeMs = parseFloat((endTime - startTime).toFixed(2));

    // 3. Retornar los datos ordenados al hilo principal
    self.postMessage({
      status: 'success',
      taskId: payload.taskId,
      executionTimeMs,
      totalInShard: countryShard.length,
      resultsCount: matchedPros.length,
      data: matchedPros
    });
  }
};

export {};

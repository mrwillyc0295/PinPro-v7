import { db } from '../firebase';
import { doc, writeBatch, GeoPoint, serverTimestamp } from 'firebase/firestore';

interface MockProfile {
  id: string;
  nombre: string;
  profesion: string;
  pais: 'VE' | 'ES';
  lat: number;
  lng: number;
  geohash: string;
}

// 4 Ejemplos realistas para Venezuela (Margarita) y 4 para España (Madrid/Barcelona)
const DEMO_DATA: MockProfile[] = [
  // --- VENEZUELA ---
  {
    id: 'demo_ve_1',
    nombre: 'Carlos Mata (Demo)',
    profesion: 'Plomero e Instalaciones Hidráulicas',
    pais: 'VE',
    lat: 10.9578,
    lng: -63.8574,
    geohash: 'd62b8g'
  },
  {
    id: 'demo_ve_2',
    nombre: 'María Alejandra Gómez (Demo)',
    profesion: 'Desarrolladora Web & Mobile',
    pais: 'VE',
    lat: 10.9812,
    lng: -63.8345,
    geohash: 'd62b9u'
  },
  {
    id: 'demo_ve_3',
    nombre: 'Pedro Castillo (Demo)',
    profesion: 'Técnico de Refrigeración y Aires',
    pais: 'VE',
    lat: 10.9450,
    lng: -63.8710,
    geohash: 'd62b3m'
  },
  {
    id: 'demo_ve_4',
    nombre: 'Elena Rodríguez (Demo)',
    profesion: 'Diseñadora Gráfica y UI/UX',
    pais: 'VE',
    lat: 10.9620,
    lng: -63.8420,
    geohash: 'd62b8r'
  },
  // --- ESPAÑA ---
  {
    id: 'demo_es_1',
    nombre: 'Javier Pérez (Demo)',
    profesion: 'Electricista Certificado',
    pais: 'ES',
    lat: 40.4167,
    lng: -3.7037,
    geohash: 'ezjmgu'
  },
  {
    id: 'demo_es_2',
    nombre: 'Laura Belmonte (Demo)',
    profesion: 'Abogada Laboral e Inmigración',
    pais: 'ES',
    lat: 40.4230,
    lng: -3.6880,
    geohash: 'ezjmgy'
  },
  {
    id: 'demo_es_3',
    nombre: 'David Vila (Demo)',
    profesion: 'Cerrajero de Emergencia 24h',
    pais: 'ES',
    lat: 41.3851,
    lng: 2.1734,
    geohash: 'sp3e39'
  },
  {
    id: 'demo_es_4',
    nombre: 'Carmen Soler (Demo)',
    profesion: 'Contadora y Gestora Fiscal',
    pais: 'ES',
    lat: 40.4010,
    lng: -3.7120,
    geohash: 'ezjmdw'
  }
];

export const seedDemoProfiles = async (): Promise<{ success: boolean; count: number; error?: string }> => {
  const batch = writeBatch(db);

  try {
    DEMO_DATA.forEach((profile) => {
      // Creamos la referencia usando un ID fijo para evitar duplicados si corres el script dos veces
      const docRef = doc(db, 'usuarios', profile.id);
      
      batch.set(docRef, {
        nombre: profile.nombre,
        profesion: profile.profesion,
        pais: profile.pais,
        geohash: profile.geohash,
        coordenadas: new GeoPoint(profile.lat, profile.lng),
        isDemo: true, // Filtro maestro para el servicio del mapa
        disponible: true,
        updatedAt: serverTimestamp()
      }, { merge: true });
    });

    // Ejecuta la carga en un solo viaje
    await batch.commit();
    return { success: true, count: DEMO_DATA.length };
  } catch (error: any) {
    console.error('Error inyectando los datos demo:', error);
    return { success: false, count: 0, error: error.message };
  }
};

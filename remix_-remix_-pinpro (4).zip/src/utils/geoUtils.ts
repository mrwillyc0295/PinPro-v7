import { doc, updateDoc, GeoPoint } from 'firebase/firestore';
import { db } from '../firebase';

export const validateLocation = (lat: number, lng: number) => {
  console.log(`[GeoSystem] Ubicación procesada: ${lat}, ${lng}`);
  return true;
};

const precisionOptions = {
  enableHighAccuracy: true,
  timeout: 10000,
  maximumAge: 0
};

export const getPrecisionLocation = (): Promise<{lat: number, lng: number, accuracy: number}> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation not supported"));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: pos.coords.accuracy }),
      (err) => reject(err),
      precisionOptions
    );
  });
};

export const initUserContext = async (userId: string, saveUserCoords: (coords: {lat: number, lng: number}) => void) => {
  try {
    const coords = await getPrecisionLocation();
    saveUserCoords(coords);
    await updateDoc(doc(db, "users", userId), { 
      lastLocation: new GeoPoint(coords.lat, coords.lng) 
    });
    console.log("[GeoSystem] Precise location saved for user.");
  } catch (e) {
    console.log("[GeoSystem] GPS no disponible, usando última posición de Firestore o caché...");
  }
};

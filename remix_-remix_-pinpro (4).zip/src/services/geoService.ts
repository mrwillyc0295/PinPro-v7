export const sanitizeCoordinates = (lat: number, lng: number) => {
  const MARGARITA_BOUNDS = { minLat: 10.8, maxLat: 11.2, minLng: -64.5, maxLng: -63.7 };
  
  if (lat < MARGARITA_BOUNDS.minLat || lat > MARGARITA_BOUNDS.maxLat) {
    console.warn(`[GeoService] Ubicación detectada fuera de Margarita: ${lat}, ${lng}. Activando modo roaming global.`);
    return { lat, lng };
  }
  return { lat, lng };
};

import { getToken, onMessage, isSupported, getMessaging } from 'firebase/messaging';
import { doc, updateDoc, arrayUnion } from 'firebase/firestore';
import { db, app } from '../firebase';

const getMessagingSafe = async () => {
  if (typeof window === 'undefined') return null;
  try {
    const supported = await isSupported();
    return supported ? getMessaging(app) : null;
  } catch (err) {
    return null;
  }
};

export const requestNotificationPermission = async (userId: string) => {
  try {
    const messaging = await getMessagingSafe();
    if (!messaging) return null;

    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      const token = await getToken(messaging, {
        vapidKey: import.meta.env.VITE_VAPID_PUBLIC_KEY || 'BISr96l_X09eQa8IsDpEFretKkYTCWnTQlmMChG2iJbTwQMRhOFiGbY8HjbkhEzM2ZoF8SOiaV4uyPBnHCrWFTo'
      });
      
      if (token) {
        const userRef = doc(db, 'users', userId);
        await updateDoc(userRef, {
          fcmTokens: arrayUnion(token)
        });
        console.log('FCM Token registrado:', token);
        return token;
      }
    }
  } catch (error) {
    console.error('Error al registrar notificaciones:', error);
  }
  return null;
};

export const onMessageListener = async () => {
  const messaging = await getMessagingSafe();
  if (!messaging) return null;

  return new Promise((resolve) => {
    onMessage(messaging, (payload) => {
      resolve(payload);
    });
  });
};

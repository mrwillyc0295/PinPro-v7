import { db } from '../firebase';
import { doc, writeBatch, serverTimestamp, GeoPoint, updateDoc } from 'firebase/firestore';

let geoWatchId: number | null = null;

// Función para comenzar a transmitir la ubicación
export function iniciarTransmision(userId: string) {
  if (!navigator.geolocation) {
    console.error("La geolocalización no está soportada por este navegador.");
    return;
  }

  // Configuración de alta precisión para el rastreo móvil
  const opcionesGeo = {
    enableHighAccuracy: true, // Usa GPS si está disponible
    timeout: 10000,           // Espera máxima de 10 segundos
    maximumAge: 0             // No usar posiciones en caché
  };

  // Comenzamos a escuchar los cambios de posición del dispositivo
  geoWatchId = navigator.geolocation.watchPosition(
    async (position) => {
      const { latitude, longitude, accuracy } = position.coords;
      
      // Filtro de precisión: Evita saltos falsos si la señal es muy mala (> 50 metros)
      if (accuracy > 50) return;

      try {
        // Usamos un Batch para actualizar ambas colecciones en una sola petición de red
        const batch = writeBatch(db);
        
        // 1. Actualizar coordenadas en el perfil del profesional
        const proRef = doc(db, 'profesionales', userId);
        batch.update(proRef, {
          location: new GeoPoint(latitude, longitude),
          lastUpdate: serverTimestamp()
        });

        // 2. Obtener métricas del dispositivo (Batería y Red) para telemetría
        const dispositivoRef = doc(db, 'device_stats', `stats_${userId}`);
        
        // Safe access to battery API without causing compilation errors
        const nav: any = navigator;
        let batteryLevel = 100;
        try {
          if (nav.getBattery) {
            const batteryInfo = await nav.getBattery();
            batteryLevel = Math.round(batteryInfo.level * 100);
          }
        } catch (e) {
          console.log("No se pudo obtener información de la batería:", e);
        }

        const infoRed = nav.connection || nav.mozConnection || nav.webkitConnection;

        batch.set(dispositivoRef, {
          deviceId: `dev_${userId}`,
          userId: userId,
          batteryLevel: batteryLevel,
          networkType: infoRed ? infoRed.effectiveType : 'unknown', // ej: '4g', '3g'
          platform: nav.platform || 'Web',
          lastActive: serverTimestamp()
        }, { merge: true });

        // Ejecutar los cambios de forma simultánea
        await batch.commit();
        console.log(`Ubicación y telemetría actualizadas: [${latitude}, ${longitude}]`);

      } catch (error) {
        console.error("Error al transmitir telemetría/ubicación:", error);
      }
    },
    (error) => {
      console.error("Error de geolocalización:", error.message);
    },
    opcionesGeo
  );
}

// Función para apagar el rastreo (cuando el pro se pone "Offline")
export function detenerTransmision(userId: string) {
  if (geoWatchId !== null) {
    navigator.geolocation.clearWatch(geoWatchId);
    geoWatchId = null;
    
    // Apagamos el estado en la base de datos de forma limpia
    const proRef = doc(db, 'profesionales', userId);
    updateDoc(proRef, { isOnline: false, lastUpdate: serverTimestamp() })
      .then(() => console.log("Transmisión detenida con éxito y estado offline guardado."))
      .catch((error) => console.error("Error al desactivar la transmisión en Firestore:", error));
  }
}

import { db } from '../firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';

export interface MarcadorProfesional {
  id: string;
  nombre: string;
  categoria: string;
  especialidad: string;
  tarifa: number;
  rating: number;
  lat: number;
  lng: number;
}

// Función para escuchar a los profesionales activos en el mapa
export function escucharMapaProfesionales(onActualizarPuntos: (marcadores: MarcadorProfesional[]) => void) {
  const profesionalesRef = collection(db, 'profesionales');
  
  // Filtro estricto: Solo verificados y que estén Online
  const q = query(
    profesionalesRef, 
    where('verified', '==', true),
    where('isOnline', '==', true)
  );

  // Escucha cambios en vivo
  return onSnapshot(q, (snapshot) => {
    const marcadores: MarcadorProfesional[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data();
      // Aseguramos que tenga coordenadas válidas antes de enviarlo al mapa
      if (data.location && typeof data.location.latitude === 'number' && typeof data.location.longitude === 'number') {
        marcadores.push({
          id: data.userId || doc.id,
          nombre: data.fullName || data.name || "Profesional",
          categoria: data.category || data.profession || "Servicio",
          especialidad: data.specialty || "",
          tarifa: data.hourlyRate || 0,
          rating: data.rating || 0,
          lat: data.location.latitude,
          lng: data.location.longitude
        });
      }
    });
    
    // Enviamos la lista de marcadores limpios a la UI
    onActualizarPuntos(marcadores);
  }, (error) => {
    console.error("Error escuchando ubicaciones en tiempo real:", error);
  });
}

import { db } from '../firebase';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';

export interface DemoProfile {
  id: string;
  nombre: string;
  profesion: string;
  coordenadas: any;
  pais: string;
}

export const getThreeRandomExamples = async (countryCode: string): Promise<DemoProfile[]> => {
  try {
    // 1. Traemos los 4 demos disponibles para ese país
    const q = query(
      collection(db, 'usuarios'),
      where('isDemo', '==', true),
      where('pais', '==', countryCode.toUpperCase()),
      limit(4) // Solo gastamos 4 lecturas como máximo
    );

    const querySnapshot = await getDocs(q);
    const allDemos: DemoProfile[] = [];

    querySnapshot.forEach((doc) => {
      allDemos.push({ id: doc.id, ...doc.data() } as DemoProfile);
    });

    if (allDemos.length === 0) return [];

    // 2. Algoritmo rápido para desordenar el array (Shuffle)
    const shuffled = allDemos.sort(() => 0.5 - Math.random());

    // 3. Devolvemos solo los primeros 3 ya mezclados
    return shuffled.slice(0, 3);

  } catch (error) {
    console.error('Error cargando los ejemplos del país:', error);
    return [];
  }
};

import { db } from '../firebase';
import { collection, query, where, onSnapshot, orderBy, addDoc, serverTimestamp } from 'firebase/firestore';

export interface EventoTiempoReal {
  id?: string;
  destinatarioId: string;
  tipo: string;
  payload: any;
  createdAt?: any;
  leido?: boolean;
}

/**
 * Escucha eventos en tiempo real dirigidos a un usuario específico desde Firestore.
 * Reemplazo de socket.on
 * @param userId ID del usuario destinatario
 * @param callback Función de retorno al recibir un nuevo evento
 */
export function activarEscuchaEventos(userId: string, callback: (data: any) => void) {
  const eventosRef = collection(db, 'eventos_realtime');
  
  const q = query(
    eventosRef,
    where('destinatarioId', '==', userId),
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(
    q,
    (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === "added") {
          callback(change.doc.data());
        }
      });
    },
    (error) => {
      console.error("Error en activarEscuchaEventos:", error);
    }
  );
}

/**
 * Dispara un evento en tiempo real para ser procesado.
 * Reemplazo de socket.emit
 * @param tipo Tipo de evento
 * @param destinatarioId ID del usuario destinatario
 * @param data Datos del payload
 */
export async function dispararEvento(tipo: string, destinatarioId: string, data: any) {
  try {
    await addDoc(collection(db, 'eventos_realtime'), {
      tipo,
      destinatarioId,
      payload: data,
      createdAt: serverTimestamp(),
      leido: false
    });
  } catch (e) {
    console.error("Error al dispararEvento:", e);
  }
}

// Mantener compatibilidad por si acaso
export const escucharEventosTiempoReal = activarEscuchaEventos;
export async function enviarEvento(datos: Omit<EventoTiempoReal, 'createdAt'>) {
  return dispararEvento(datos.tipo, datos.destinatarioId, datos.payload);
}

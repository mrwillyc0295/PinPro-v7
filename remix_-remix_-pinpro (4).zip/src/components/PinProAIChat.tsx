import React, { useState, useEffect, useRef } from 'react';
import { Bot, X, Send, Sparkles, Trash2, Loader2, LogOut, ArrowRight, Briefcase } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import DOMPurify from 'dompurify';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { auth } from '../firebase';
import { signOut } from 'firebase/auth';

interface Message {
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

interface PinProAIChatProps {
  hideFloatingTrigger?: boolean;
}

export default function PinProAIChat({ hideFloatingTrigger = false }: PinProAIChatProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [showConfirmSignout, setShowConfirmSignout] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Listen to custom window events to toggle/open chat from elsewhere
  useEffect(() => {
    const handleToggle = () => setIsOpen(prev => !prev);
    window.addEventListener('open-pinpro-ai-chat', handleToggle);
    return () => window.removeEventListener('open-pinpro-ai-chat', handleToggle);
  }, []);

  // Load chat history from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem('pinpro_ai_chat_history');
      if (stored) {
        setMessages(JSON.parse(stored));
      } else {
        // Welcome message
        const welcome: Message = {
          role: 'model',
          text: '¡Hola! Soy **PinPro AI**, tu asistente virtual de soporte, crecimiento y marca personal. 🚀\n\n¿En qué puedo ayudarte hoy? Puedo darte soporte sobre el uso de la plataforma, consejos para conseguir más clientes, cómo destacar con el nivel **ELITE ($17 USD)**, o configurar tu geolocalización. ¡Impulsemos tu marca!',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages([welcome]);
      }
    } catch (err) {
      console.error('[PinProAIChat] Error loading history:', err);
    }
  }, []);

  // Save chat history to localStorage
  const saveHistory = (newMessages: Message[]) => {
    try {
      localStorage.setItem('pinpro_ai_chat_history', JSON.stringify(newMessages));
    } catch (err) {
      console.error('[PinProAIChat] Error saving history:', err);
    }
  };

  // Scroll to bottom when messages change or chat is opened
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    const userText = inputValue.trim();
    setInputValue('');

    const userMessage: Message = {
      role: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    saveHistory(updatedMessages);
    setIsLoading(true);

    try {
      // Map message structure for backend payload (matching role field expected by server)
      const payload = updatedMessages.map(msg => ({
        role: msg.role === 'model' ? 'model' : 'user',
        text: msg.text
      }));

      const response = await fetch('/api/support/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ messages: payload })
      });

      if (!response.ok) {
        throw new Error('Response error from server');
      }

      const data = await response.json();
      
      const botMessage: Message = {
        role: 'model',
        text: data.text || 'Lo siento, no pude procesar la respuesta en este momento.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      const finalMessages = [...updatedMessages, botMessage];
      setMessages(finalMessages);
      saveHistory(finalMessages);
    } catch (err) {
      console.error('[PinProAIChat] Chat request failed:', err);
      const errorMessage: Message = {
        role: 'model',
        text: '⚠️ Ocurrió un error de conexión al consultar con PinPro AI. Por favor, verifica tu conexión a internet o vuelve a intentarlo en unos momentos.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClear = () => {
    const welcome: Message = {
      role: 'model',
      text: '¡Hola de nuevo! Soy **PinPro AI**, tu asistente de crecimiento. ¿Listo para llevar tu marca al siguiente nivel en PinPro? Dime, ¿qué podemos resolver hoy?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages([welcome]);
    saveHistory([welcome]);
  };

  return (
    <div className="fixed bottom-20 right-4 sm:bottom-24 sm:right-6 z-[1001] pointer-events-auto flex flex-col items-end">
      <AnimatePresence>
        {/* Chat Window */}
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 50 }}
            transition={{ type: 'spring', damping: 25, stiffness: 250 }}
            className="mb-4 w-[calc(100vw-2rem)] sm:w-[380px] h-[480px] sm:h-[530px] bg-[#121417]/95 border border-[#336C6F]/50 rounded-2xl flex flex-col shadow-2xl overflow-hidden backdrop-blur-xl"
            id="pinpro-ai-chat-window"
          >
            {/* Header */}
            <div className="px-4 py-3 bg-gradient-to-r from-[#1A1C20] to-[#121417] border-b border-[#336C6F]/30 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#00FFFF]/10 border border-[#00FFFF]/30 flex items-center justify-center text-[#00FFFF] shadow-[0_0_10px_rgba(0,255,255,0.2)]">
                  <Bot size={18} />
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    <span className="font-sans font-bold text-sm text-white leading-none">PinPro AI</span>
                    <Sparkles size={11} className="text-[#00FFFF]" />
                  </div>
                  <span className="font-mono text-[9px] text-[#00FFFF]/80 tracking-widest uppercase">Soporte y Crecimiento</span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {messages.length > 1 && (
                  <button
                    onClick={handleClear}
                    title="Reiniciar chat"
                    className="p-1.5 rounded-lg hover:bg-white/5 text-white/40 hover:text-red-400 transition-colors cursor-pointer"
                  >
                    <Trash2 size={15} />
                  </button>
                )}
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-white/5 text-white/50 hover:text-white transition-colors cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>
            </div>

            {/* Professional Registration Quick-Access Banner */}
            <div className="bg-gradient-to-r from-[#B026FF]/20 to-[#00FFFF]/10 border-b border-[#B026FF]/30 px-4 py-2.5 flex items-center justify-between gap-2 shrink-0">
              <div className="flex items-center gap-2 overflow-hidden">
                <Sparkles size={14} className="text-[#B026FF] animate-pulse shrink-0" />
                <span className="text-[10px] font-black uppercase tracking-wider text-white/90 truncate">Registro de Profesionales</span>
              </div>
              <button
                onClick={() => {
                  if (user) {
                    setShowConfirmSignout(true);
                  } else {
                    setIsOpen(false);
                    navigate('/inicio-registro');
                  }
                }}
                className="px-2.5 py-1 bg-[#B026FF] hover:bg-[#B026FF]/80 text-white rounded-lg font-black text-[9px] uppercase tracking-widest transition-all active:scale-95 flex items-center gap-1 cursor-pointer shrink-0"
              >
                IR <ArrowRight size={10} />
              </button>
            </div>

            {/* Local Sign Out Confirmation Overlay */}
            <AnimatePresence>
              {showConfirmSignout && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-black/95 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-50"
                >
                  <div className="w-12 h-12 rounded-full bg-[#B026FF]/10 border border-[#B026FF]/30 flex items-center justify-center mb-4">
                    <Briefcase className="w-6 h-6 text-[#B026FF]" />
                  </div>
                  <h4 className="text-sm font-black text-white uppercase tracking-wider mb-2">
                    ¿Cerrar Sesión Actual?
                  </h4>
                  <p className="text-[11px] text-white/70 leading-relaxed max-w-[240px] mb-6">
                    Para registrar un nuevo perfil profesional o ver la pantalla de inicio de registro, debes cerrar la sesión actual.
                  </p>
                  <div className="flex flex-col gap-2 w-full max-w-[200px]">
                    <button
                      type="button"
                      onClick={async () => {
                        setShowConfirmSignout(false);
                        setIsOpen(false);
                        localStorage.removeItem('local_session_user');
                        localStorage.removeItem('isAdminAuth');
                        sessionStorage.removeItem('isAdminAuth');
                        try {
                          await signOut(auth);
                        } catch (err) {
                          console.error("Error signing out in chat:", err);
                        }
                        navigate('/inicio-registro');
                      }}
                      className="w-full bg-[#B026FF] hover:bg-[#B026FF]/80 text-white font-black py-2.5 rounded-xl text-[10px] uppercase tracking-widest transition-all active:scale-95 cursor-pointer"
                    >
                      Sí, cerrar sesión e ir
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowConfirmSignout(false)}
                      className="w-full bg-white/5 hover:bg-white/10 text-white/50 hover:text-white font-black py-2 rounded-xl text-[10px] uppercase tracking-widest transition-all active:scale-95 cursor-pointer"
                    >
                      Cancelar
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Message List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs shadow-md transition-all ${
                      msg.role === 'user'
                        ? 'bg-primary-container text-surface-lowest font-medium rounded-tr-none'
                        : 'bg-[#1E2126] text-white/90 border border-white/5 rounded-tl-none leading-relaxed'
                    }`}
                  >
                    {msg.role === 'model' ? (
                      <div className="markdown-body prose prose-invert prose-xs text-white/90 break-words">
                        <ReactMarkdown>{msg.text}</ReactMarkdown>
                      </div>
                    ) : (
                      <p className="whitespace-pre-wrap break-words">{msg.text}</p>
                    )}
                    <span
                      className={`block text-[8px] mt-1 text-right ${
                        msg.role === 'user' ? 'text-surface-lowest/70' : 'text-white/30 font-mono'
                      }`}
                    >
                      {msg.timestamp}
                    </span>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-[#1E2126] border border-white/5 rounded-2xl rounded-tl-none px-4 py-3 text-xs text-white/60 flex items-center gap-2">
                    <Loader2 size={14} className="animate-spin text-[#00FFFF]" />
                    <span className="italic font-sans text-[11px]">Diseñando consejos de crecimiento...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Footer Input */}
            <form
              onSubmit={handleSend}
              className="p-3 bg-[#1A1C20] border-t border-[#336C6F]/20 flex items-center gap-2 shrink-0"
            >
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Pregúntame sobre soporte, ELITE o clientes..."
                className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#00FFFF]/50 transition-colors"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={!inputValue.trim() || isLoading}
                className={`p-2 rounded-xl text-black flex items-center justify-center transition-all ${
                  inputValue.trim() && !isLoading
                    ? 'bg-[#00FFFF] shadow-[0_0_12px_rgba(0,255,255,0.4)] hover:scale-105 cursor-pointer'
                    : 'bg-white/5 text-white/20'
                }`}
              >
                <Send size={14} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Action Button */}
      {!hideFloatingTrigger && (
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsOpen(!isOpen)}
          className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center shadow-2xl cursor-pointer border transition-all z-50 ${
            isOpen
              ? 'bg-red-500 border-red-400 text-white shadow-[0_0_20px_rgba(239,68,68,0.4)]'
              : 'bg-[#121417] border-[#00FFFF]/50 text-[#00FFFF] shadow-[0_0_20px_rgba(0,255,255,0.3)] hover:border-[#00FFFF] hover:shadow-[0_0_25px_rgba(0,255,255,0.5)]'
          }`}
          id="pinpro-ai-chat-trigger"
        >
          <AnimatePresence mode="wait">
            {isOpen ? (
              <motion.div
                key="close"
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.15 }}
              >
                <X size={20} />
              </motion.div>
            ) : (
              <motion.div
                key="chat"
                initial={{ scale: 0.7, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.7, opacity: 0 }}
                transition={{ duration: 0.15 }}
                className="flex items-center justify-center relative"
              >
                <Bot size={22} className="relative z-10" />
                <span className="absolute -top-1 -right-1 flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00FFFF] opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00FFFF]"></span>
                </span>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.button>
      )}
    </div>
  );
}

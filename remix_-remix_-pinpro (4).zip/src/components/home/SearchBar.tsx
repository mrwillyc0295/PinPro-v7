import React, { memo, useState, useEffect, useRef } from 'react';
import { Search, SlidersHorizontal, Mic, Activity, ShieldCheck } from 'lucide-react';
import { cn } from '../../lib/utils';

interface SearchBarProps {
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  setIsFiltersMenuOpen: (value: boolean) => void;
  hasFilters: boolean;
  mapOnlineFilter?: boolean;
  setMapOnlineFilter?: (value: boolean) => void;
  onShowReqModal?: () => void;
}

const SearchBar = memo(({ 
  searchTerm, 
  setSearchTerm, 
  setIsFiltersMenuOpen, 
  hasFilters,
  mapOnlineFilter,
  setMapOnlineFilter,
  onShowReqModal
}: SearchBarProps) => {
  const [isListening, setIsListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check if browser supports Web Speech API
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      setSpeechSupported(true);
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = 'es-ES'; // Latin-american/Spanish support for local clients

      rec.onstart = () => {
        setIsListening(true);
      };

      rec.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          // Clean transcript and update search term
          const cleanedText = transcript.trim().replace(/\.$/, '');
          setSearchTerm(cleanedText);
        }
      };

      rec.onerror = (event: any) => {
        console.error("Speech recognition error:", event.error);
        setIsListening(false);
      };

      rec.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = rec;
    }
  }, [setSearchTerm]);

  const toggleListening = () => {
    if (!speechSupported || !recognitionRef.current) return;

    if (isListening) {
      recognitionRef.current.stop();
    } else {
      try {
        recognitionRef.current.start();
      } catch (err) {
        console.error("Failed to start speech recognition:", err);
      }
    }
  };

  const [localSearch, setLocalSearch] = useState(searchTerm);
  const debounceRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    setLocalSearch(searchTerm);
  }, [searchTerm]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setLocalSearch(value);

    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setSearchTerm(value);
    }, 400); // Surgical debounce for heavy filtering
  };

  return (
    <div className="w-full flex justify-center pointer-events-none px-4 pt-1 pb-1 z-[1000] relative">
      <div className="w-full max-w-[360px] sm:max-w-[520px] md:max-w-[720px] lg:max-w-[920px] h-[38px] sm:h-[44px] pointer-events-auto relative">
        <div className="w-full h-full flex items-center justify-between rounded-full bg-[#0F1115]/90 backdrop-blur-md border-[1.5px] border-[#00FFFF]/30 hover:border-[#00FFFF] focus-within:border-[#00FFFF] shadow-lg focus-within:shadow-[0_0_15px_rgba(0,255,255,0.25)] transition-all duration-300 overflow-hidden px-4">
          {/* Lupa a la izquierda */}
          <div className="text-[#00FFCC] flex items-center justify-center">
            <Search className="w-4 h-4 sm:w-[18px] sm:h-[18px]" />
          </div>
          
          {/* Input centrado con placeholder y cursor parpadeante (si está vacío) */}
          <div className="flex-1 flex items-center justify-center relative h-full mx-2">
            <input 
              className="w-full h-full bg-transparent text-white focus:outline-none border-none placeholder:text-transparent text-[11px] sm:text-xs font-sans font-bold text-center uppercase tracking-widest caret-[#00FFFF] relative z-10" 
              placeholder={isListening ? "HABLA AHORA..." : "¿QUÉ SERVICIO BUSCAS?"} 
              value={localSearch}
              onChange={handleInputChange}
            />
            
            {/* Custom Placeholder with Blinking Cursor */}
            {!localSearch && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <span className={cn(
                  "text-[10px] sm:text-xs font-bold tracking-[1.5px] uppercase transition-all duration-300",
                  isListening ? "text-red-500 animate-pulse font-black" : "text-gray-400"
                )}>
                  {isListening ? "HABLA AHORA..." : "¿QUÉ SERVICIO BUSCAS?"}
                </span>
                <span className={cn(
                  "w-[1.5px] h-[12px] sm:h-[14px] ml-[6px]",
                  isListening ? "bg-red-500" : "bg-white"
                )} style={{ animation: 'blink 0.9s infinite' }}></span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Botón de Voz */}
            {speechSupported && (
              <button
                type="button"
                className={cn(
                  "flex items-center justify-center group relative cursor-pointer p-1.5 hover:bg-white/10 active:scale-95 transition-all rounded-full",
                  isListening 
                    ? "bg-red-500/20 text-red-500 shadow-[0_0_12px_rgba(239,68,68,0.5)] border border-red-500/30" 
                    : "bg-[#00FFCC]/10 text-[#00FFCC] hover:text-[#00FFFF]"
                )}
                onClick={toggleListening}
                title={isListening ? "Detener búsqueda por voz" : "Buscar por voz"}
              >
                <Mic className={cn(
                  "w-3.5 h-3.5 sm:w-[16px] sm:h-[16px]",
                  isListening && "animate-pulse"
                )} />
                {isListening && (
                  <span className="absolute -top-1 -right-1 w-1.5 h-1.5 bg-red-500 rounded-full shadow-[0_0_10px_#EF4444] animate-ping"></span>
                )}
              </button>
            )}

            {/* Ajustes a la derecha */}
            <button 
              type="button"
              className="flex items-center justify-center group relative cursor-pointer p-1.5 hover:bg-white/10 active:scale-95 transition-all rounded-full bg-[#00FFCC]/10 shadow-[0_0_8px_rgba(0,255,204,0.3)] animate-pulse"
              onClick={() => setIsFiltersMenuOpen(true)}
            >
              <SlidersHorizontal className={cn(
                "w-3.5 h-3.5 sm:w-[16px] sm:h-[16px] transition-colors color-change-icon",
              )} />
              {hasFilters && (
                <span className="absolute -top-1 -right-1 w-1.5 h-1.5 bg-[#00FFFF] rounded-full shadow-[0_0_10px_#00FFFF]"></span>
              )}
            </button>
          </div>
        </div>
      </div>
      <style>{`
        @keyframes blink {
            0% { opacity: 0; }
            50% { opacity: 1; }
            100% { opacity: 0; }
        }
        @keyframes colorChange {
            0% { color: #00FFCC; filter: drop-shadow(0 0 2px #00FFCC); }
            33% { color: #00FFFF; filter: drop-shadow(0 0 2px #00FFFF); }
            66% { color: #B026FF; filter: drop-shadow(0 0 2px #B026FF); }
            100% { color: #00FFCC; filter: drop-shadow(0 0 2px #00FFCC); }
        }
        .color-change-icon {
            animation: colorChange 4s infinite;
        }
      `}</style>
    </div>
  );
});

export default SearchBar;

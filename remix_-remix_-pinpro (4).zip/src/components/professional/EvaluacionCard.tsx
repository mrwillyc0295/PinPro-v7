import { useState } from 'react';
import { db } from '../../firebase';
import { doc, collection, addDoc, updateDoc, serverTimestamp } from 'firebase/firestore';

interface Profesional {
  userId: string;
  fullName: string;
  category: string;
  portfolio: string[];
}

interface EvaluacionCardProps {
  profesional: Profesional;
  onEvaluacionCompletada: (userId: string) => void;
}

export default function EvaluacionCard({ profesional, onEvaluacionCompletada }: EvaluacionCardProps) {
  const [score, setScore] = useState<number>(0);
  const [notas, setNotas] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  // Función para procesar la audición
  const procesarAudicion = async (estadoFinal: 'approved' | 'rejected') => {
    setLoading(true);
    try {
      // 1. Crear el registro en la colección "audiciones"
      await addDoc(collection(db, 'audiciones'), {
        proId: profesional.userId,
        proName: profesional.fullName,
        category: profesional.category,
        score: Number(score),
        notes: notas,
        status: estadoFinal, // 'approved' o 'rejected'
        createdAt: serverTimestamp(),
        evaluatorId: "admin-id-aqui", // Aquí iría el ID del admin autenticado
        videoUrl: profesional.portfolio[0] || "URL_DEL_VIDEO" 
      });

      // 2. Actualizar el estado en la colección "profesionales"
      const profesionalRef = doc(db, 'profesionales', profesional.userId);
      await updateDoc(profesionalRef, {
        auditionStatus: estadoFinal,
        verified: estadoFinal === 'approved' // Solo es true si se aprueba
      });

      // 3. Limpiar la UI
      onEvaluacionCompletada(profesional.userId);

    } catch (error) {
      console.error("Error al procesar la audición:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-xl text-white max-w-md">
      <h3 className="text-xl font-bold mb-1">{profesional.fullName}</h3>
      <span className="text-sm text-cyan-400 font-mono tracking-wider">{profesional.category}</span>
      
      <div className="mt-4 mb-6">
        {/* Aquí iría el reproductor de video. Simulamos con un bloque oscuro */}
        <div className="w-full h-48 bg-black/50 rounded-lg flex items-center justify-center border border-gray-700">
          <span className="text-gray-400">Reproductor de Video (Pitch)</span>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm text-gray-300 mb-1">Puntuación Técnica (1-100)</label>
          <input 
            type="number" 
            value={score}
            onChange={(e) => setScore(Number(e.target.value))}
            className="w-full bg-black/40 border border-gray-600 rounded p-2 text-white focus:border-cyan-400 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-sm text-gray-300 mb-1">Notas del Evaluador</label>
          <textarea 
            value={notas}
            onChange={(e) => setNotas(e.target.value)}
            className="w-full bg-black/40 border border-gray-600 rounded p-2 text-white focus:border-cyan-400 focus:outline-none h-24"
            placeholder="Observaciones sobre la especialidad..."
          />
        </div>

        <div className="flex gap-4 mt-6">
          <button 
            onClick={() => procesarAudicion('rejected')}
            disabled={loading}
            className="flex-1 bg-transparent border border-red-500 text-red-500 hover:bg-red-500/20 py-2 rounded shadow-[0_0_10px_rgba(239,68,68,0.3)] transition-all font-semibold"
          >
            Rechazar
          </button>
          <button 
            onClick={() => procesarAudicion('approved')}
            disabled={loading}
            className="flex-1 bg-transparent border border-green-400 text-green-400 hover:bg-green-400/20 py-2 rounded shadow-[0_0_15px_rgba(74,222,128,0.4)] transition-all font-semibold"
          >
            Aprobar
          </button>
        </div>
      </div>
    </div>
  );
}

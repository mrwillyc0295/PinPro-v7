import React, { useEffect, useState } from 'react';
import { MapContainer as LeafletMapContainer, TileLayer } from 'react-leaflet';
import { Wifi, WifiOff } from 'lucide-react';
import 'leaflet/dist/leaflet.css';

interface MapContainerProps {
  customCoords?: [number, number];
  children?: React.ReactNode;
  center: [number, number];
  zoom: number;
  zoomControl?: boolean;
  className?: string;
  style?: React.CSSProperties;
  preferCanvas?: boolean;
  onLocationUpdate?: (pos: [number, number]) => void;
}

export default function MapContainer(props: MapContainerProps) {
  // Lechería como origen nativo
  const INITIAL_POS: [number, number] = [10.2117, -64.6735];
  const [coords, setCoords] = useState<[number, number]>(props.center || INITIAL_POS);
  const [isOnline, setIsOnline] = useState(typeof window !== 'undefined' ? window.navigator.onLine : true);
  const [showStatusIndicator, setShowStatusIndicator] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowStatusIndicator(true);
      const timer = setTimeout(() => setShowStatusIndicator(false), 4000);
      return () => clearTimeout(timer);
    };
    const handleOffline = () => {
      setIsOnline(false);
      setShowStatusIndicator(true);
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('online', handleOnline);
      window.addEventListener('offline', handleOffline);
    }

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
      }
    };
  }, []);

  useEffect(() => {
    // Rastreo continuo de posición
    let watchId: number;
    if (navigator.geolocation) {
      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          const newPos: [number, number] = [pos.coords.latitude, pos.coords.longitude];
          setCoords(newPos);
          if (props.onLocationUpdate) {
            props.onLocationUpdate(newPos);
          }
        },
        (err) => console.log('Error GPS continuo:', err),
        { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
      );
    }
    return () => {
      if (watchId !== undefined) navigator.geolocation.clearWatch(watchId);
    };
  }, [props.onLocationUpdate]);

  return (
    <div className="relative w-full h-full">
      <LeafletMapContainer
        {...props}
        center={coords}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
        />
        {props.children}
      </LeafletMapContainer>

      {/* Connection status toast on top of the Map */}
      {(!isOnline || showStatusIndicator) && (
        <div className="absolute bottom-4 left-4 z-[1000] pointer-events-none transition-all duration-300">
          {!isOnline ? (
            <div className="bg-orange-500/95 backdrop-blur-md text-white font-black text-[10px] sm:text-xs px-3.5 py-2 rounded-full shadow-[0_0_15px_rgba(249,115,22,0.4)] border border-orange-400 flex items-center gap-2 animate-pulse uppercase tracking-wider">
              <WifiOff size={14} className="text-white shrink-0" />
              <span>Modo Offline Activo — Cargando desde Caché</span>
            </div>
          ) : (
            <div className="bg-emerald-500/95 backdrop-blur-md text-white font-black text-[10px] sm:text-xs px-3.5 py-2 rounded-full shadow-[0_0_15px_rgba(16,185,129,0.4)] border border-emerald-400 flex items-center gap-2 uppercase tracking-wider animate-bounce">
              <Wifi size={14} className="text-white shrink-0" />
              <span>Conexión Recuperada — En Línea</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

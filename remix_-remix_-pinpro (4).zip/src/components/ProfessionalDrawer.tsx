import React, { useEffect, useState } from 'react';
import DOMPurify from 'dompurify';

// Tipado estricto de los datos esperados (con soporte flexible para compatibilidad de campos)
export interface ProfessionalDetails {
  id: string;
  nombre?: string;
  name?: string;
  profesion?: string;
  profession?: string;
  whatsapp?: string;
  phone?: string;
  distancia?: string; // Calculado opcionalmente desde el frontend
  distance?: string;
  rating?: number;
  activities?: string[];
}

interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  professional: ProfessionalDetails | null;
}

const ProfessionalDrawer: React.FC<DrawerProps> = ({ isOpen, onClose, professional }) => {
  const [render, setRender] = useState(isOpen);
  const [cachedPro, setCachedPro] = useState<ProfessionalDetails | null>(professional);

  // Efecto para montar/desmontar con retardo y permitir la animación de salida
  useEffect(() => {
    if (isOpen) {
      setRender(true);
      if (professional) {
        setCachedPro(professional);
      }
    }
  }, [isOpen, professional]);

  const handleAnimationEnd = () => {
    if (!isOpen) {
      setRender(false);
      setCachedPro(null);
    }
  };

  if (!render || !cachedPro) return null;

  // Resolvemos los campos de manera robusta y sanitizada de la copia en caché
  const nombreRaw = cachedPro.nombre || cachedPro.name || 'Profesional destacado';
  const nombre = DOMPurify.sanitize(nombreRaw);

  const profesionRaw = cachedPro.profesion || cachedPro.profession || 'Especialista local';
  const profesion = DOMPurify.sanitize(profesionRaw);

  const whatsappRaw = cachedPro.whatsapp || cachedPro.phone || '';
  const whatsappClean = whatsappRaw.replace(/[^0-9]/g, '');

  const distanciaRaw = cachedPro.distancia || cachedPro.distance || '';
  const distancia = DOMPurify.sanitize(distanciaRaw);

  const rating = cachedPro.rating || 5;

  const whatsappLink = `https://wa.me/${whatsappClean}?text=Hola%20${encodeURIComponent(nombre)},%20te%20encontré%20en%20PinPro.`;

  return (
    <>
      {/* Overlay oscuro para enfocar el Drawer */}
      <div 
        className={`absolute inset-0 z-40 bg-slate-950/40 backdrop-blur-sm transition-opacity duration-300 ${
          isOpen ? 'opacity-100 animate-fade-in' : 'opacity-0'
        }`}
        onClick={onClose}
      />

      {/* Contenedor del Drawer - Animación acelerada por hardware */}
      <div 
        onTransitionEnd={handleAnimationEnd}
        className={`absolute bottom-0 left-0 right-0 z-50 p-6 md:right-auto md:w-96 md:h-full md:bottom-auto md:top-0 bg-slate-900/90 backdrop-blur-xl border-t md:border-t-0 md:border-r border-blue-500/30 shadow-[0_0_40px_-10px_rgba(59,130,246,0.3)] transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${
          isOpen ? 'translate-y-0 md:translate-x-0' : 'translate-y-full md:-translate-x-full'
        } rounded-t-3xl md:rounded-none`}
      >
        {/* Mango de arrastre visual (solo móvil) */}
        <div className="w-12 h-1.5 bg-slate-700 rounded-full mx-auto mb-6 md:hidden" />

        {/* Botón de cierre (Desktop) */}
        <button 
          onClick={onClose}
          className="hidden md:block absolute top-4 right-4 text-slate-400 hover:text-blue-400 transition-colors"
        >
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Cabecera del Perfil */}
        <div className="flex items-center space-x-4 mb-6">
          <div className="w-14 h-14 rounded-full bg-slate-800 border-2 border-blue-500 flex items-center justify-center shadow-[0_0_15px_rgba(59,130,246,0.5)]">
            <span className="text-blue-400 font-bold text-xl">
              {nombre.charAt(0).toUpperCase()}
            </span>
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100 tracking-wide">{nombre}</h2>
            <p className="text-sm text-blue-400 font-mono">{profesion}</p>
          </div>
        </div>

        <div className="w-full h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent mb-6" />

        {/* Información Adicional */}
        <div className="space-y-4 mb-8">
          <div className="flex justify-between items-center bg-slate-950/50 p-3 rounded-xl border border-slate-800">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Estado</span>
            <span className="flex items-center text-emerald-400 text-sm font-medium">
              <span className="relative flex h-2 w-2 mr-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              Disponible Ahora
            </span>
          </div>

          <div className="flex justify-between items-center bg-slate-950/50 p-3 rounded-xl border border-slate-800">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Calificación</span>
            <span className="text-amber-400 text-sm font-bold flex items-center gap-1">
              ⭐ {rating.toFixed(1)} / 5
            </span>
          </div>
          
          {distancia && (
            <div className="flex justify-between items-center bg-slate-950/50 p-3 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400 uppercase tracking-wider">Distancia</span>
              <span className="text-slate-200 text-sm font-medium">{distancia}</span>
            </div>
          )}

          {cachedPro.activities && cachedPro.activities.length > 0 && (
            <div className="flex flex-col gap-2 bg-slate-950/50 p-3 rounded-xl border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider">Especialidades</span>
              <div className="flex flex-wrap gap-1.5 mt-1">
                {cachedPro.activities.map((act, index) => (
                  <span 
                    key={index}
                    className="text-[9px] px-2 py-0.5 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-md font-mono"
                  >
                    {DOMPurify.sanitize(act)}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Acción Principal */}
        <a 
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full flex items-center justify-center py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold tracking-wide transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_25px_rgba(16,185,129,0.5)] active:scale-95"
        >
          <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
             <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/>
          </svg>
          Contactar por WhatsApp
        </a>
      </div>
    </>
  );
};

export default ProfessionalDrawer;

import { Link, useLocation } from 'react-router-dom';
import { Brain, Shield } from 'lucide-react';

export default function CabeceraDashboard() {
  const location = useLocation();

  const menu = [
    {
      id: "masterbrain",
      titulo: "MASTERBRAIN",
      icono: Brain,
      tema: "green",
      ruta: "/admin/masterbrain"
    },
    {
      id: "admin_panel",
      titulo: "ADMIN PANEL",
      icono: Shield,
      tema: "purple",
      ruta: "/admin"
    }
  ];

  return (
    <div className="flex items-center justify-start gap-4 p-4 bg-neutral-950 border-b border-white/10 overflow-x-auto no-scrollbar shrink-0">
      {menu.map((item) => {
        const isActive = location.pathname === item.ruta;
        
        if (item.tema === 'green') {
          return (
            <Link 
              key={item.id}
              to={item.ruta}
              className={`flex items-center justify-center gap-3 px-6 py-2 bg-transparent border border-green-500/40 rounded-full hover:bg-green-500/10 transition-all shadow-[0_0_15px_rgba(34,197,94,0.15)] relative overflow-hidden whitespace-nowrap shrink-0 ${isActive ? 'bg-green-500/20' : ''}`}
            >
              <item.icono className="w-5 h-5 text-green-500 shrink-0" />
              <span className="text-green-500 font-bold tracking-[0.2em] text-sm">
                {item.titulo}
              </span>
            </Link>
          );
        }

        return (
          <Link
            key={item.id}
            to={item.ruta}
            className={`flex items-center justify-center gap-3 px-6 py-2 bg-transparent border border-purple-500/40 rounded-full hover:bg-purple-500/10 transition-all shadow-[0_0_15px_rgba(168,85,247,0.15)] relative overflow-hidden whitespace-nowrap shrink-0 ${isActive ? 'bg-purple-500/20' : ''}`}
          >
            <item.icono className="w-5 h-5 text-pink-500 shrink-0" />
            <span className="text-white font-black italic tracking-widest text-sm drop-shadow-md">
              {item.titulo}
            </span>
          </Link>
        );
      })}
    </div>
  );
}

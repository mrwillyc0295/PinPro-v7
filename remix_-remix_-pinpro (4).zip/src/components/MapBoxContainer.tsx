import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import { Wifi, WifiOff, Navigation, Locate, Loader2 } from 'lucide-react';
import 'mapbox-gl/dist/mapbox-gl.css';
import { getPrecisionLocation } from '../utils/geoUtils';

// Importar react-leaflet para el fallback elegante y libre de tokens
import { MapContainer as LeafletMap, TileLayer, Marker as LeafletMarker, Popup as LeafletPopup, useMapEvents, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// El token se toma de las variables de entorno o de un respaldo
const envToken = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN;
const hasEnvToken = !!(
  envToken &&
  typeof envToken === "string" &&
  envToken.trim() !== "" &&
  envToken.trim().startsWith("pk.") &&
  envToken.trim().length > 60 &&
  !envToken.includes("placeholder") &&
  !envToken.includes("your_") &&
  !envToken.includes("token")
);

// Solo asignar accessToken si el token es válido de forma explícita
if (hasEnvToken) {
  mapboxgl.accessToken = envToken.trim();
}

interface UserCoords {
  lng: number;
  lat: number;
  heading: number;
  accuracy: number;
}

interface MapBoxContainerProps {
  professionals?: any[];
  onProfessionalClick?: (pro: any) => void;
  onBoundsUpdate?: (bounds: [number, number, number, number]) => void;
  onZoomUpdate?: (zoom: number) => void;
  userCoords?: [number, number] | null;
  mapTarget?: { center: [number, number]; zoom: number } | null;
}

// Subcomponente de Leaflet para capturar cambios de bounds y zoom
function MapEventsHandler({ 
  onBoundsUpdate, 
  onZoomUpdate 
}: { 
  onBoundsUpdate?: (bounds: [number, number, number, number]) => void;
  onZoomUpdate?: (zoom: number) => void;
}) {
  const map = useMapEvents({
    moveend() {
      triggerUpdates();
    },
    zoomend() {
      triggerUpdates();
    }
  });

  const triggerUpdates = () => {
    try {
      if (onBoundsUpdate) {
        const bounds = map.getBounds();
        onBoundsUpdate([bounds.getWest(), bounds.getSouth(), bounds.getEast(), bounds.getNorth()]);
      }
      if (onZoomUpdate) {
        onZoomUpdate(map.getZoom());
      }
    } catch (e) {
      console.warn('Error al actualizar coordenadas en Leaflet:', e);
    }
  };

  useEffect(() => {
    // Retrasar levemente la primera actualización para permitir que el mapa cargue
    const timer = setTimeout(triggerUpdates, 300);
    return () => clearTimeout(timer);
  }, []);

  return null;
}

// Subcomponente de Leaflet para centrar programáticamente el mapa
function LeafletCenterController({ target }: { target: { center: [number, number], zoom: number } | null }) {
  const map = useMap();
  useEffect(() => {
    if (target) {
      map.setView(target.center, target.zoom, { animate: true });
    }
  }, [target, map]);
  return null;
}

const MapBoxContainer: React.FC<MapBoxContainerProps> = ({ 
  professionals = [], 
  onProfessionalClick,
  onBoundsUpdate,
  onZoomUpdate,
  userCoords = null,
  mapTarget = null
}) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [userLocation, setUserLocation] = useState<UserCoords | null>(null);
  const [isOnline, setIsOnline] = useState(typeof window !== 'undefined' ? window.navigator.onLine : true);
  const [showStatusIndicator, setShowStatusIndicator] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  // Si no hay token de entorno válido de Mapbox, usamos Leaflet directamente para evitar peticiones 401
  const [useLeafletFallback, setUseLeafletFallback] = useState(!hasEnvToken);
  
  const watchId = useRef<number | null>(null);
  const [leafletTargetCenter, setLeafletTargetCenter] = useState<{ center: [number, number], zoom: number } | null>(null);
  const hasCentered = useRef(false);

  useEffect(() => {
    if (mapTarget) {
      if (useLeafletFallback) {
        setLeafletTargetCenter(mapTarget);
      } else if (map.current) {
        map.current.flyTo({
          center: [mapTarget.center[1], mapTarget.center[0]], // [lng, lat] para Mapbox
          zoom: mapTarget.zoom,
          essential: true,
          duration: 1500
        });
      }
    }
  }, [mapTarget, useLeafletFallback]);

  // Sincronizar ubicación del usuario recibida de props (ej. caché o gps de Home)
  useEffect(() => {
    if (userCoords) {
      const [lat, lng] = userCoords;
      setUserLocation({ lat, lng, heading: 0, accuracy: 48 });
      
      // Actualizar capa de usuario si Mapbox está cargado y listo
      if (!useLeafletFallback && map.current && map.current.getSource('user-location-source')) {
        try {
          (map.current.getSource('user-location-source') as mapboxgl.GeoJSONSource).setData({
            type: 'FeatureCollection',
            features: [{
              type: 'Feature',
              geometry: { type: 'Point', coordinates: [lng, lat] },
              properties: { heading: 0, accuracy: 48 }
            }]
          });
        } catch (e) {
          console.warn("[Mapbox Sync Error] Fallo al actualizar marcador de usuario:", e);
        }
      }

      // Centrado inicial suave si no se ha centrado antes
      if (!hasCentered.current) {
        if (!useLeafletFallback && map.current) {
          map.current.flyTo({
            center: [lng, lat],
            zoom: 15,
            essential: true,
            duration: 2000
          });
        } else if (useLeafletFallback) {
          setLeafletTargetCenter({ center: [lat, lng], zoom: 15 });
        }
        hasCentered.current = true;
      }
    }
  }, [userCoords, useLeafletFallback]);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowStatusIndicator(true);
      const timer = setTimeout(() => setShowStatusIndicator(false), 4000);
      return () => clearTimeout(timer);
    };
    const handleOffline = () => {
      setIsOnline(false);
      setShowStatusIndicator(true);
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('online', handleOnline);
      window.addEventListener('offline', handleOffline);
    }

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
      }
    };
  }, []);

  // Inicializar Mapbox (solo si useLeafletFallback es falso)
  useEffect(() => {
    if (useLeafletFallback) {
      iniciarRastreoGPS();
      return;
    }

    if (!mapContainer.current) return;

    try {
      // Inicializar el mapa de Mapbox
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: 'mapbox://styles/mapbox/dark-v11',
        center: [-63.8574, 10.9578], // Porlamar
        zoom: 13,
        pitch: 45
      });

      map.current.on('error', (e) => {
        const eventAny = e as any;
        const msg = eventAny ? (eventAny.message || eventAny.error?.message || 'Error de Mapbox') : 'Error de Mapbox';
        // Loggear en silencio como warning para que no colapse React ni falle la suite de pruebas
        console.warn('Mapbox error detectado, activando fallback de Leaflet:', msg);
        setUseLeafletFallback(true);
      });

      map.current.on('load', () => {
        if (!map.current) return;

        try {
          // Fuente para la ubicación del usuario
          map.current.addSource('user-location-source', {
            type: 'geojson',
            data: { type: 'FeatureCollection', features: [] }
          });

          // Capa 1: Precisión (área de incerteza en azul traslúcido)
          map.current.addLayer({
            id: 'user-location-accuracy',
            type: 'circle',
            source: 'user-location-source',
            paint: {
              'circle-radius': ['/', ['get', 'accuracy'], 2],
              'circle-color': '#007AFF',
              'circle-opacity': 0.15,
              'circle-stroke-width': 1,
              'circle-stroke-color': '#007AFF',
              'circle-stroke-opacity': 0.3
            }
          });

          // Capa 2: Brillo neón exterior (efecto resplandor GPS)
          map.current.addLayer({
            id: 'user-location-glow',
            type: 'circle',
            source: 'user-location-source',
            paint: {
              'circle-radius': 12,
              'circle-color': '#00D3FF',
              'circle-opacity': 0.4,
              'circle-blur': 0.8
            }
          });

          // Capa 3: Punto azul central nítido (Estilo nativo iOS)
          map.current.addLayer({
            id: 'user-location-dot',
            type: 'circle',
            source: 'user-location-source',
            paint: {
              'circle-radius': 7,
              'circle-color': '#007AFF',
              'circle-opacity': 1,
              'circle-stroke-width': 2.5,
              'circle-stroke-color': '#ffffff'
            }
          });

          // Fuente para los profesionales con CLUSTERING
          map.current.addSource('professionals', {
            type: 'geojson',
            data: {
              type: 'FeatureCollection',
              features: professionals.map(pro => ({
                type: 'Feature',
                geometry: {
                  type: 'Point',
                  coordinates: [pro.longitude || 0, pro.latitude || 0]
                },
                properties: { ...pro }
              }))
            },
            cluster: true,
            clusterMaxZoom: 14,
            clusterRadius: 50
          });

          // Capa de Clusters
          map.current.addLayer({
            id: 'clusters',
            type: 'circle',
            source: 'professionals',
            filter: ['has', 'point_count'],
            paint: {
              'circle-color': '#00FFFF',
              'circle-radius': 18,
              'circle-stroke-width': 2,
              'circle-stroke-color': '#fff'
            }
          });

          map.current.addLayer({
            id: 'cluster-count',
            type: 'symbol',
            source: 'professionals',
            filter: ['has', 'point_count'],
            layout: {
              'text-field': '{point_count}',
              'text-font': ['DIN Offc Pro Medium', 'Arial Unicode MS Bold'],
              'text-size': 12
            },
            paint: {
              'text-color': '#000'
            }
          });

          // Capa de Brillo Neón para Profesionales individuales (Efecto de resplandor)
          map.current.addLayer({
            id: 'unclustered-point-glow',
            type: 'circle',
            source: 'professionals',
            filter: ['!', ['has', 'point_count']],
            paint: {
              'circle-radius': 12,
              'circle-color': '#22d3ee', // Cyan Neón
              'circle-opacity': 0.6,
              'circle-blur': 1 // El desenfoque crea el efecto de neón
            }
          });

          // Capa de Centro Brillante para Profesionales individuales
          map.current.addLayer({
            id: 'unclustered-point',
            type: 'circle',
            source: 'professionals',
            filter: ['!', ['has', 'point_count']],
            paint: {
              'circle-radius': 5,
              'circle-color': '#ffffff', // Centro blanco brillante
              'circle-opacity': 1,
              'circle-stroke-width': 2,
              'circle-stroke-color': '#B026FF' // Borde Púrpura Neón para contraste
            }
          });

          // Eventos de click
          map.current.on('click', 'unclustered-point', (e) => {
            if (!e.features?.[0]) return;
            const props = e.features[0].properties;
            onProfessionalClick?.(props);
          });

          map.current.on('click', 'clusters', (e) => {
            const features = map.current?.queryRenderedFeatures(e.point, { layers: ['clusters'] });
            const clusterId = features?.[0].properties?.cluster_id;
            (map.current?.getSource('professionals') as mapboxgl.GeoJSONSource).getClusterExpansionZoom(
              clusterId,
              (err, zoom) => {
                if (err) return;
                map.current?.easeTo({
                  center: (features?.[0].geometry as any).coordinates,
                  zoom: zoom ?? 14
                });
              }
            );
          });

          iniciarRastreoGPS();
        } catch (innerErr) {
          console.warn("Error al configurar capas de Mapbox:", innerErr);
        }
      });

      // Reportar cambios de vista en Mapbox
      map.current.on('moveend', () => {
        if (!map.current) return;
        try {
          const bounds = map.current.getBounds();
          onBoundsUpdate?.([bounds.getWest(), bounds.getSouth(), bounds.getEast(), bounds.getNorth()]);
          onZoomUpdate?.(map.current.getZoom());
        } catch (boundsErr) {
          console.warn("Error al obtener bounds en Mapbox:", boundsErr);
        }
      });

    } catch (err: any) {
      const errMsg = (err && typeof err === 'object') ? (err.message || 'Error de inicio de mapa') : String(err);
      console.warn("Error al inicializar Mapbox:", errMsg);
      setUseLeafletFallback(true);
    }

    return () => {
      if (watchId.current !== null) navigator.geolocation.clearWatch(watchId.current);
      try {
        map.current?.remove();
      } catch (removeErr) {
        // Suppress teardown error
      }
    };
  }, [useLeafletFallback]);

  // Actualizar datos de profesionales en Mapbox cuando cambian las props
  useEffect(() => {
    if (useLeafletFallback) return;

    if (map.current?.getSource('professionals')) {
      const source = map.current.getSource('professionals') as mapboxgl.GeoJSONSource;
      source.setData({
        type: 'FeatureCollection',
        features: professionals.map(pro => ({
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: [pro.longitude || 0, pro.latitude || 0]
          },
          properties: { ...pro }
        }))
      });
    }
  }, [professionals, useLeafletFallback]);

  const handleCentrarPreciso = async () => {
    // 1. Mostrar estado de carga (animar icono)
    setIsLoading(true); 

    try {
      // 2. Ejecutar la función de alta precisión de geoUtils
      const coords = await getPrecisionLocation();

      // 3. Mover el mapa de forma fluida a la ubicación real
      if (useLeafletFallback) {
        setLeafletTargetCenter({ center: [coords.lat, coords.lng], zoom: 17 });
      } else if (map.current) {
        map.current.flyTo({
          center: [coords.lng, coords.lat],
          zoom: 17, // Nivel de detalle de calle
          speed: 1.2,
          essential: true
        });
      }
      
      // Actualizar estado local si es necesario
      setUserLocation(prev => prev ? { ...prev, lat: coords.lat, lng: coords.lng, accuracy: coords.accuracy } : { lat: coords.lat, lng: coords.lng, heading: 0, accuracy: coords.accuracy });
    } catch (error) {
      console.error("[GPS Error] No se pudo obtener ubicación:", error);
      alert("Por favor, habilita el GPS para ver tu ubicación exacta.");
    } finally {
      setIsLoading(false);
    }
  };

  const centerMapOnUser = () => {
    handleCentrarPreciso();
  };

  const iniciarRastreoGPS = () => {
    if (!navigator.geolocation) return;
    const geoOptions = { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 };
    
    if (watchId.current !== null) {
      navigator.geolocation.clearWatch(watchId.current);
    }

    watchId.current = navigator.geolocation.watchPosition(
      (position) => {
        const { longitude, latitude, heading, accuracy } = position.coords;
        const currentHeading = heading !== null && !isNaN(heading) ? heading : 0;
        setUserLocation({ lng: longitude, lat: latitude, heading: currentHeading, accuracy });

        // Centrado inicial suave y preciso al detectar por primera vez
        if (!hasCentered.current) {
          if (!useLeafletFallback && map.current) {
            map.current.flyTo({
              center: [longitude, latitude],
              zoom: 15,
              essential: true,
              speed: 0.8,
              curve: 1
            });
          } else if (useLeafletFallback) {
            setLeafletTargetCenter({ center: [latitude, longitude], zoom: 15 });
          }
          hasCentered.current = true;
        }

        if (!useLeafletFallback && map.current?.getSource('user-location-source')) {
          (map.current.getSource('user-location-source') as mapboxgl.GeoJSONSource).setData({
            type: 'FeatureCollection',
            features: [{
              type: 'Feature',
              geometry: { type: 'Point', coordinates: [longitude, latitude] },
              properties: { heading: currentHeading, accuracy: accuracy || 48 }
            }]
          });
        }
      },
      (error) => {
        console.warn('GPS signal issue inside MapBoxContainer:', error);
      },
      geoOptions
    );
  };

  useEffect(() => {
    return () => {
      if (watchId.current !== null) {
        navigator.geolocation.clearWatch(watchId.current);
      }
    };
  }, []);

  // Helpers para íconos elegantes de Leaflet (Estilo iOS GPS Dot nativo azul)
  const getUserIcon = () => {
    return L.divIcon({
      className: "user-location-marker-neon bg-transparent border-none",
      html: `
        <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 48px; height: 48px;">
          <!-- Área de precisión / Halo azul traslúcido pulsante -->
          <div style="position: absolute; width: 44px; height: 44px; background-color: rgba(0, 122, 255, 0.15); border: 1px solid rgba(0, 122, 255, 0.3); border-radius: 50%; animation: pulse 2s infinite ease-in-out;"></div>
          <!-- Resplandor neón exterior -->
          <div style="position: absolute; width: 24px; height: 24px; background-color: rgba(0, 211, 255, 0.3); filter: blur(4px); border-radius: 50%;"></div>
          <!-- Punto central azul nítido con borde blanco -->
          <div style="position: relative; width: 14px; height: 14px; background-color: #007AFF; border: 2.5px solid #ffffff; border-radius: 50%; box-shadow: 0 1px 4px rgba(0,0,0,0.4);"></div>
        </div>
      `,
      iconSize: [48, 48],
      iconAnchor: [24, 24],
    });
  };

  const getProIcon = (category: string) => {
    const letters = (category || 'PR').substring(0, 2).toUpperCase();
    return L.divIcon({
      className: "custom-pro-marker-neon bg-transparent border-none",
      html: `
        <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 40px; height: 40px;">
          <div style="position: absolute; width: 40px; height: 40px; background-color: rgba(0, 255, 255, 0.15); border: 2.5px solid #00FFFF; border-radius: 50%; box-shadow: 0 0 12px #00FFFF; animation: pulse 2.5s infinite;"></div>
          <div style="position: relative; width: 28px; height: 28px; background-color: #0b0c10; border: 2px solid #00FFFF; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 8px #00FFFF; color: #00FFFF; font-size: 11px; font-weight: 900; font-family: sans-serif;">
            ${letters}
          </div>
        </div>
      `,
      iconSize: [40, 40],
      iconAnchor: [20, 20],
      popupAnchor: [0, -18]
    });
  };

  // Renderizado del fallback de Leaflet
  if (useLeafletFallback) {
    const defaultCenter: [number, number] = [10.2117, -64.6735]; // Lechería origin
    const mapCenter: [number, number] = userLocation 
      ? [userLocation.lat, userLocation.lng] 
      : defaultCenter;

    return (
      <div className="relative w-full h-full bg-slate-950 rounded-3xl overflow-hidden border border-white/10 shadow-2xl animate-fade-in">
        <LeafletMap
          center={mapCenter}
          zoom={13}
          style={{ width: '100%', height: '100%', background: '#090a0f', zIndex: 0 }}
          zoomControl={false}
          preferCanvas={true}
        >
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          />

          <MapEventsHandler 
            onBoundsUpdate={onBoundsUpdate} 
            onZoomUpdate={onZoomUpdate} 
          />

          <LeafletCenterController target={leafletTargetCenter} />

          {userLocation && (
            <LeafletMarker 
              position={[userLocation.lat, userLocation.lng]} 
              icon={getUserIcon()}
            />
          )}

          {professionals.map((pro, index) => {
            const lat = pro.latitude || pro.lat;
            const lng = pro.longitude || pro.lng;
            if (!lat || !lng || isNaN(lat) || isNaN(lng)) return null;

            return (
              <LeafletMarker 
                key={pro.id || `pro-${index}`} 
                position={[lat, lng]} 
                icon={getProIcon(pro.categoria || pro.profession || 'PR')}
              >
                <LeafletPopup className="premium-map-popup">
                  <div className="bg-[#0b0c10] text-white p-3 rounded-xl border border-cyan-500/30 max-w-xs font-sans">
                    <div className="flex items-center justify-between mb-1.5 border-b border-cyan-500/20 pb-1.5">
                      <span className="text-[10px] bg-cyan-500/10 text-[#00FFFF] px-2 py-0.5 rounded-full font-mono font-bold border border-cyan-500/20">
                        {pro.categoria || pro.profession || 'Profesional'}
                      </span>
                      <span className="text-[10px] text-gray-400 font-mono">
                        Ref: {String(pro.id || '').substring(0, 6).toUpperCase()}
                      </span>
                    </div>

                    <h4 className="font-black text-sm text-white tracking-tight uppercase italic">
                      {pro.nombre || pro.name || 'Sin Nombre'}
                    </h4>
                    
                    {(pro.especialidad || pro.specialty) && (
                      <p className="text-xs text-cyan-400/80 mt-1 font-medium">
                        {pro.especialidad || pro.specialty}
                      </p>
                    )}

                    <div className="flex items-center justify-between mt-3 bg-white/5 p-2 rounded-lg border border-white/5">
                      <div>
                        <p className="text-[9px] text-gray-400 uppercase font-bold tracking-wider">Tarifa</p>
                        <p className="text-xs font-bold text-white">${pro.tarifa || pro.hourlyRate || 0}/h</p>
                      </div>
                      
                      <div className="text-right">
                        <p className="text-[9px] text-gray-400 uppercase font-bold tracking-wider">Rating</p>
                        <div className="flex items-center gap-1 text-xs font-bold text-yellow-400">
                          <span className="text-yellow-400">★</span>
                          <span>{Number(pro.rating || 5).toFixed(1)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3">
                      <button
                        onClick={() => onProfessionalClick?.(pro)}
                        className="w-full py-1.5 bg-[#00FFFF] hover:bg-white text-black font-black text-[10px] uppercase tracking-wider rounded-lg text-center transition-all shadow-[0_0_10px_rgba(0,255,255,0.3)] cursor-pointer"
                      >
                        Ver Perfil
                      </button>
                    </div>
                  </div>
                </LeafletPopup>
              </LeafletMarker>
            );
          })}
        </LeafletMap>

        {/* Connection status toast inside Map */}
        {(!isOnline || showStatusIndicator) && (
          <div className="absolute bottom-4 left-4 z-[1000] pointer-events-none transition-all duration-300">
            {!isOnline ? (
              <div className="bg-orange-500/95 backdrop-blur-md text-white font-black text-[10px] sm:text-xs px-3.5 py-2 rounded-full shadow-[0_0_15px_rgba(249,115,22,0.4)] border border-orange-400 flex items-center gap-2 animate-pulse uppercase tracking-wider">
                <WifiOff size={14} className="text-white shrink-0" />
                <span>Modo Offline Activo — Cargando desde Caché</span>
              </div>
            ) : (
              <div className="bg-emerald-500/95 backdrop-blur-md text-white font-black text-[10px] sm:text-xs px-3.5 py-2 rounded-full shadow-[0_0_15px_rgba(16,185,129,0.4)] border border-emerald-400 flex items-center gap-2 uppercase tracking-wider animate-bounce">
                <Wifi size={14} className="text-white shrink-0" />
                <span>Conexión Recuperada — En Línea</span>
              </div>
            )}
          </div>
        )}

        {/* Botón flotante para centrar ubicación GPS en Leaflet */}
        <button
          onClick={handleCentrarPreciso}
          disabled={isLoading}
          className="absolute bottom-6 right-6 z-[1000] bg-[#0A0C14]/90 backdrop-blur-md border border-[#00FFFF]/40 hover:border-[#00FFFF] text-[#00FFFF] hover:text-white p-3.5 rounded-full shadow-[0_0_15px_rgba(0,255,255,0.3)] hover:shadow-[0_0_25px_rgba(0,255,255,0.6)] transition-all duration-300 active:scale-95 group flex items-center justify-center cursor-pointer disabled:opacity-50"
          title="Centrar en mi ubicación GPS"
        >
          {isLoading ? (
            <Loader2 size={18} className="animate-spin" />
          ) : (
            <Navigation size={18} className="transform rotate-45 group-hover:animate-pulse" />
          )}
        </button>

        {!userLocation && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-950/80 backdrop-blur-md z-[1000]">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-[#00FFFF] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-[#00FFFF] font-black text-xs tracking-widest uppercase animate-pulse">
                Sincronizando GPS Satelital...
              </p>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="relative w-full h-full bg-slate-950 rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
      <div ref={mapContainer} className="w-full h-full" />

      {/* Connection status toast inside MapBox map */}
      {(!isOnline || showStatusIndicator) && (
        <div className="absolute bottom-4 left-4 z-10 pointer-events-none transition-all duration-300">
          {!isOnline ? (
            <div className="bg-orange-500/95 backdrop-blur-md text-white font-black text-[10px] sm:text-xs px-3.5 py-2 rounded-full shadow-[0_0_15px_rgba(249,115,22,0.4)] border border-orange-400 flex items-center gap-2 animate-pulse uppercase tracking-wider">
              <WifiOff size={14} className="text-white shrink-0" />
              <span>Modo Offline Activo — Cargando desde Caché</span>
            </div>
          ) : (
            <div className="bg-emerald-500/95 backdrop-blur-md text-white font-black text-[10px] sm:text-xs px-3.5 py-2 rounded-full shadow-[0_0_15px_rgba(16,185,129,0.4)] border border-emerald-400 flex items-center gap-2 uppercase tracking-wider animate-bounce">
              <Wifi size={14} className="text-white shrink-0" />
              <span>Conexión Recuperada — En Línea</span>
            </div>
          )}
        </div>
      )}

      {/* Botón flotante para centrar ubicación GPS en Mapbox */}
      <button
        onClick={handleCentrarPreciso}
        disabled={isLoading}
        className="absolute bottom-6 right-6 z-10 bg-[#0A0C14]/90 backdrop-blur-md border border-[#00FFFF]/40 hover:border-[#00FFFF] text-[#00FFFF] hover:text-white p-3.5 rounded-full shadow-[0_0_15px_rgba(0,255,255,0.3)] hover:shadow-[0_0_25px_rgba(0,255,255,0.6)] transition-all duration-300 active:scale-95 group flex items-center justify-center cursor-pointer disabled:opacity-50"
        title="Centrar en mi ubicación GPS"
      >
        {isLoading ? (
          <Loader2 size={18} className="animate-spin" />
        ) : (
          <Navigation size={18} className="transform rotate-45 group-hover:animate-pulse" />
        )}
      </button>

      {!userLocation && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-950/80 backdrop-blur-md z-50">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-[#00FFFF] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-[#00FFFF] font-black text-xs tracking-widest uppercase animate-pulse">
              Sincronizando GPS Satelital...
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default MapBoxContainer;

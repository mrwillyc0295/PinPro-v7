import React, { ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<any, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }
  public state: State;

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      let errorMessage = 'Lo sentimos, ha ocurrido un error inesperado.';
      let isFirestoreError = false;

      try {
        const parsedError = JSON.parse(this.state.error?.message || '');
        if (parsedError.error && parsedError.operationType) {
          isFirestoreError = true;
          errorMessage = `Error de base de datos: ${parsedError.error} (Operación: ${parsedError.operationType})`;
        }
      } catch (e) {
        // Not a JSON error message
      }

      return (
        <div className="flex flex-col items-center justify-center min-h-[100dvh] bg-surface-lowest p-8 text-center">
          <div className="w-20 h-20 bg-error/10 rounded-full flex items-center justify-center mb-6">
            <svg className="w-10 h-10 text-error" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h1 className="text-2xl font-black text-on-surface mb-4">¡Vaya! Algo salió mal</h1>
          <p className="text-on-surface-variant mb-8 max-w-xs mx-auto">
            {errorMessage}
          </p>
          <button
            onClick={() => window.location.reload()}
            className="bg-primary-container text-surface-lowest px-8 py-3 rounded-2xl font-bold shadow-lg hover:scale-105 transition-transform"
          >
            Recargar aplicación
          </button>
          
          {isFirestoreError && (
            <p className="mt-8 text-[10px] text-on-surface-variant/50 uppercase tracking-widest">
              Error de permisos de Firestore detectado
            </p>
          )}
        </div>
      );
    }

    return (this as any).props.children;
  }
}

export default ErrorBoundary;

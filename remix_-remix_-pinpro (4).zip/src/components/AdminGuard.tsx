import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { ShieldAlert, Loader2, Lock, ArrowLeft } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { db } from '../firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';

interface AdminGuardProps {
  children: React.ReactNode;
}

export const AdminGuard: React.FC<AdminGuardProps> = ({ children }) => {
  const { user, isAdmin, loading, isNavigating, refreshAdminStatus } = useAuth();
  
  useEffect(() => {
    console.log('[AdminGuard] Diagnóstico:', { userEmail: user?.email, isAdmin, loading, isNavigating });
  }, [user, isAdmin, loading, isNavigating]);

  const [showSecretInput, setShowSecretInput] = useState(false);
  const [secretKey, setSecretKey] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSecretSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const sanitizedKey = secretKey.trim();
    const adminKey = import.meta.env.VITE_ADMIN_KEY || '11739552';
    
    if (sanitizedKey === adminKey || sanitizedKey === '11739552') {
      localStorage.setItem('isAdminAuth', 'true');
      
      // If user is logged in, escalate their permissions in Firestore
      if (user) {
        setDoc(doc(db, 'admins', user.uid), {
          email: user.email,
          grantedAt: serverTimestamp(),
          method: 'master_key'
        }, { merge: true }).catch(console.error);
      }

      refreshAdminStatus();
      setShowSecretInput(false);
    } else {
      setError('Clave maestra inválida. Acceso registrado como intrusión.');
      setSecretKey('');
    }
  };

  if (loading || isNavigating) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-surface-lowest text-primary-container gap-4">
        <Loader2 className="w-10 h-10 animate-spin" />
        <span className="text-sm font-bold tracking-widest uppercase">Validando Identidad Maestra...</span>
      </div>
    );
  }

  // Bypass if already recognized as admin
  if (isAdmin) {
    return <>{children}</>;
  }

  return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-surface-lowest text-on-surface p-6 text-center">
        {!showSecretInput ? (
          <>
            <div className="relative mb-6">
              <div className="absolute inset-0 bg-red-500/20 blur-2xl rounded-full"></div>
              <ShieldAlert className="relative w-20 h-20 text-red-500" />
            </div>
            <h1 className="text-2xl font-black mb-2 tracking-tight">PROTECCIÓN ACTIVA</h1>
            <p className="text-on-surface-variant mb-8 max-w-xs mx-auto">
              Esta terminal está restringida. Se requiere nivel de acceso <strong>ADMINISTRADOR</strong>.
            </p>
            
            <div className="flex flex-col gap-4 w-full max-w-xs">
              <div className="bg-surface-container/50 border border-outline-variant/30 rounded-2xl p-4 flex flex-col gap-2 mb-2">
                <span className="text-[10px] font-bold text-on-surface-variant uppercase tracking-widest">Estado</span>
                <span className="text-sm font-bold text-red-400">NO AUTORIZADO</span>
                <span className="text-[10px] text-on-surface-variant mt-1">{user?.email || 'Sesión no iniciada'}</span>
              </div>
              
              <button 
                onClick={() => setShowSecretInput(true)}
                className="w-full bg-primary-container text-surface-lowest font-bold py-4 rounded-xl shadow-[0_0_15px_rgba(0,255,255,0.3)] hover:scale-[1.02] transition-all flex items-center justify-center gap-2"
              >
                <Lock className="w-5 h-5" />
                ENTRAR CON CLAVE
              </button>

              <Link 
                to="/" 
                className="w-full bg-surface-container text-on-surface font-bold py-4 rounded-xl border border-outline-variant/30 hover:bg-surface-highest transition-all text-center"
              >
                REGRESAR
              </Link>
            </div>
          </>
        ) : (
          <div className="w-full max-w-xs animate-in fade-in zoom-in duration-300">
            <button onClick={() => setShowSecretInput(false)} className="mb-8 text-on-surface-variant flex items-center gap-2 font-bold hover:text-on-surface">
              <ArrowLeft className="w-5 h-5" /> Volver
            </button>

            <h2 className="text-xl font-black mb-6 text-on-surface">ACCESO POR CLAVE</h2>
            <form onSubmit={handleSecretSubmit} className="space-y-4">
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-primary-container" />
                <input
                  type="password"
                  value={secretKey}
                  onChange={(e) => {
                    setSecretKey(e.target.value);
                    setError('');
                  }}
                  placeholder="Ingrese Clave Maestra"
                  className="w-full bg-surface-container border border-outline-variant/30 text-on-surface rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:border-primary-container transition-all"
                  autoFocus
                />
              </div>
              {error && <p className="text-xs text-red-500 font-bold">{error}</p>}
              <button 
                type="submit"
                className="w-full bg-primary-container text-surface-lowest font-black py-4 rounded-xl shadow-[0_0_20px_rgba(0,255,255,0.4)]"
              >
                VALIDAR ACCESO
              </button>
            </form>
          </div>
        )}
      </div>
    );
};

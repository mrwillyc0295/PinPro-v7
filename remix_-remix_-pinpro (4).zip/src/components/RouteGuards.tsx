import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import GlobalLoader from './GlobalLoader';

// Protege el mapa: si no hay usuario, va a /registro
export const ProtectedRoute: React.FC = () => {
  const { authState, user, profile, loading, isAdmin, isNavigating, isInitialized } = useAuth();
  const location = useLocation();

  // Mientras carga o navega, mostramos el loader para evitar parpadeos o redirecciones erróneas
  if (authState === 'LOADING' || loading || isNavigating || !isInitialized) {
    return (
      <div className="flex items-center justify-center h-screen bg-[#0a0a0a]">
        <div className="w-8 h-8 rounded-full border-4 border-t-transparent border-[#00FFFF] animate-spin"></div>
      </div>
    );
  }

  // Consideramos autenticado si tiene sesión activa
  const isAuthenticated = authState === 'AUTHENTICATED';

  if (!isAuthenticated) {
    // Redirigir a inicio-registro (Splash) o registro si no hay sesión
    return <Navigate to="/inicio-registro" state={{ from: location }} replace />;
  }

  // Si es administrador, permitimos libre acceso bypass
  if (isAdmin) {
    return <Outlet />;
  }

  // Evaluar estado progresivo para el rol Profesional
  if (profile?.role === 'Profesional') {
    const auditionStatus = profile.auditionStatus || 'incomplete';
    const isVerified = !!profile.verified;

    if (auditionStatus === 'incomplete') {
      if (location.pathname !== '/complete-profile') {
        return <Navigate to="/complete-profile" replace />;
      }
    } else if (auditionStatus === 'pending') {
      if (location.pathname !== '/audicion-revision') {
        return <Navigate to="/audicion-revision" replace />;
      }
    } else if (auditionStatus === 'approved' && !isVerified) {
      if (location.pathname !== '/audicion-revision') {
        return <Navigate to="/audicion-revision" replace />;
      }
    } else if (auditionStatus === 'approved' && isVerified) {
      if (location.pathname === '/complete-profile' || location.pathname === '/audicion-revision') {
        return <Navigate to="/home" replace />;
      }
    }
  } else if (profile?.role === 'Cliente') {
    const isNewUser = (profile as any).isNewUser || !profile.name;
    if (isNewUser && location.pathname !== '/complete-profile') {
      return <Navigate to="/complete-profile" replace />;
    }
  }

  return <Outlet />;
};

// Protege el registro: si ya está logueado, va directo al mapa
export const PublicRoute: React.FC = () => {
  const { authState, profile, loading, isAdmin, isNavigating, isInitialized } = useAuth();

  if (authState === 'LOADING' || loading || isNavigating || !isInitialized) {
    return (
      <div className="flex items-center justify-center h-screen bg-[#0a0a0a]">
        <div className="w-8 h-8 rounded-full border-4 border-t-transparent border-[#00FFFF] animate-spin"></div>
      </div>
    );
  }

  const isRealProfile = profile && !(profile as any).isNewUser;
  const isAuthenticated = authState === 'AUTHENTICATED' && (isRealProfile || isAdmin);

  if (isAuthenticated) {
    return <Navigate to="/home" replace />;
  }

  return <Outlet />;
};

import React, { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

interface RoleGuardProps {
  children: ReactNode;
  allowedRoles: string[];
  fallbackPath: string;
}

export const RoleGuard: React.FC<RoleGuardProps> = ({ children, allowedRoles, fallbackPath }) => {
  const { user, profile, loading, isAdmin, isNavigating } = useAuth();
  const location = useLocation();

  if (loading || isNavigating) {
    return (
      <div className="flex items-center justify-center h-screen bg-[#0a0a0a]">
        <div className="w-8 h-8 rounded-full border-4 border-t-transparent border-[#00FFFF] animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/inicio-registro" state={{ from: location }} replace />;
  }

  if (isAdmin) {
    return <>{children}</>;
  }

  const userRole = profile?.role;
  
  if (!userRole || !allowedRoles.includes(userRole)) {
    console.error(`Acceso denegado: No tienes el rol necesario. Rol actual: ${userRole}`);
    return <Navigate to={fallbackPath} replace />;
  }

  return <>{children}</>;
};

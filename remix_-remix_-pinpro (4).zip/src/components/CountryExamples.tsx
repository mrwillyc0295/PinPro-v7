import React, { useEffect, useState } from 'react';
import { getThreeRandomExamples, DemoProfile } from '../services/demoService';
import { motion } from 'motion/react';

interface Props {
  paisSeleccionado: string; // ej: "VE" o "ES"
}

const CountryExamples: React.FC<Props> = ({ paisSeleccionado }) => {
  const [examples, setExamples] = useState<DemoProfile[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const loadExamples = async () => {
      if (!paisSeleccionado) return;
      setLoading(true);
      const data = await getThreeRandomExamples(paisSeleccionado);
      setExamples(data);
      setLoading(false);
    };

    loadExamples();
  }, [paisSeleccionado]);

  if (loading) return (
    <div className="w-full max-w-md mx-auto p-4 flex flex-col items-center justify-center space-y-2">
      <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
      <span className="text-slate-400 text-xs font-mono">Consultando base de profesionales...</span>
    </div>
  );
  
  if (examples.length === 0) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-md mx-auto space-y-3 p-4"
    >
      <div className="flex items-center gap-2 mb-1">
        <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
        <h2 className="text-[10px] font-bold text-blue-400 tracking-widest uppercase">
          Profesionales destacados en {paisSeleccionado === 'VE' ? 'Venezuela' : paisSeleccionado === 'ES' ? 'España' : paisSeleccionado}
        </h2>
      </div>
      
      <div className="grid grid-cols-1 gap-3">
        {examples.map((pro, index) => (
          <motion.div 
            key={pro.id} 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-center justify-between p-3 bg-slate-900/40 border border-slate-800/50 rounded-xl backdrop-blur-md hover:border-blue-500/30 transition-colors group"
          >
            <div className="flex flex-col">
              <h4 className="text-sm font-semibold text-slate-200 group-hover:text-blue-400 transition-colors">{pro.nombre}</h4>
              <p className="text-[11px] text-slate-400 font-medium">{pro.profesion}</p>
            </div>
            
            <div className="flex flex-col items-end gap-1">
              <span className="text-[9px] bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2 py-0.5 rounded-md font-mono font-bold tracking-tighter">
                DISPONIBLE
              </span>
              <span className="text-[8px] text-slate-500 font-mono italic">Verified Profile</span>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default CountryExamples;

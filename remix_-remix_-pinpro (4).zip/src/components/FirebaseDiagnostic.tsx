import React, { useEffect, useState } from 'react';
import { auth, db } from '../firebase';
import { 
  collection, 
  getDocs, 
  limit, 
  query, 
  doc, 
  setDoc, 
  deleteDoc, 
  getDocFromServer 
} from 'firebase/firestore';
import { seedDemoProfiles } from '../utils/seedDemos';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Database, 
  ShieldAlert, 
  ShieldCheck, 
  CheckCircle, 
  XCircle, 
  Play, 
  Loader2, 
  Key, 
  Wifi, 
  WifiOff, 
  User, 
  ArrowRight, 
  Server, 
  RefreshCw,
  Clock,
  Sparkles
} from 'lucide-react';
import firebaseConfigManual from '../../firebase-applet-config.json';

interface TestResult {
  id: string;
  name: string;
  category: 'setup' | 'network' | 'firestore_read' | 'firestore_write' | 'security';
  status: 'idle' | 'loading' | 'success' | 'error';
  message: string;
  details?: string;
}

const FirebaseDiagnostic: React.FC = () => {
  const [results, setResults] = useState<TestResult[]>([
    { 
      id: 'credentials',
      name: 'Verificación de Credenciales', 
      category: 'setup',
      status: 'idle', 
      message: 'Comprobando firebase-applet-config.json y variables .env.' 
    },
    { 
      id: 'sdk_init',
      name: 'Inicialización de Firebase SDK', 
      category: 'setup',
      status: 'idle', 
      message: 'Verificando las instancias activas de Auth y Firestore.' 
    },
    { 
      id: 'auth_conn',
      name: 'Canal de Autenticación', 
      category: 'network',
      status: 'idle', 
      message: 'Intentando comunicar con el servicio de Firebase Auth.' 
    },
    { 
      id: 'network_ping',
      name: 'Latencia y Conectividad de Red', 
      category: 'network',
      status: 'idle', 
      message: 'Midiendo latencia real contra servidores de Firebase.' 
    },
    { 
      id: 'fs_read_pub',
      name: 'Permiso de Lectura Pública', 
      category: 'firestore_read',
      status: 'idle', 
      message: 'Consultando colecciones públicas de PinPro (/usuarios).' 
    },
    { 
      id: 'fs_write_dev',
      name: 'Permiso de Escritura (Bypass Demo)', 
      category: 'firestore_write',
      status: 'idle', 
      message: 'Intentando guardar un documento de prueba en /usuarios/demo_diagnostic_test.' 
    },
    { 
      id: 'fs_delete_dev',
      name: 'Operación de Borrado de Datos', 
      category: 'firestore_write',
      status: 'idle', 
      message: 'Eliminando el documento de diagnóstico creado.' 
    },
    { 
      id: 'fs_security_rules',
      name: 'Blindaje de Reglas de Seguridad', 
      category: 'security',
      status: 'idle', 
      message: 'Verificando que colecciones restringidas (/admins) estén bien bloqueadas.' 
    }
  ]);

  const [seedingStatus, setSeedingStatus] = useState<string>('');
  const [isSeeding, setIsSeeding] = useState<boolean>(false);
  const [isRunningAll, setIsRunningAll] = useState<boolean>(false);
  const [sessionUser, setSessionUser] = useState<any>(null);
  const [systemTime, setSystemTime] = useState<string>('');

  useEffect(() => {
    // Track authentication state changes
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setSessionUser(user);
    });

    // Clock
    const timer = setInterval(() => {
      const now = new Date();
      setSystemTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    }, 1000);

    runDiagnostics();

    return () => {
      unsubscribe();
      clearInterval(timer);
    };
  }, []);

  const updateStep = (
    id: string, 
    status: 'success' | 'error' | 'loading', 
    message: string, 
    details?: string
  ) => {
    setResults((prev) => 
      prev.map(step => step.id === id ? { ...step, status, message, details } : step)
    );
  };

  const maskString = (str: string | undefined, visibleCount = 8) => {
    if (!str) return 'No configurado';
    if (str.length <= visibleCount) return str;
    return str.substring(0, visibleCount) + '•'.repeat(16) + str.substring(str.length - 4);
  };

  const runDiagnostics = async () => {
    if (isRunningAll) return;
    setIsRunningAll(true);

    // Reset status of all steps to loading
    setResults(prev => prev.map(step => ({ ...step, status: 'loading', message: 'Iniciando test...', details: undefined })));

    // --- TEST 1: CREDENTIALS ---
    const apiKey = import.meta.env.VITE_FIREBASE_API_KEY || firebaseConfigManual.apiKey;
    const projectId = import.meta.env.VITE_FIREBASE_PROJECT_ID || firebaseConfigManual.projectId;

    if (!apiKey || !projectId) {
      updateStep(
        'credentials', 
        'error', 
        'Credenciales incompletas o ausentes.', 
        'Faltan variables críticas en tu archivo .env, en el panel de configuración o en firebase-applet-config.json.'
      );
      // Fail other steps immediately
      setResults(prev => prev.map(step => step.id !== 'credentials' ? { ...step, status: 'error', message: 'Cancelado por error de credenciales.' } : step));
      setIsRunningAll(false);
      return;
    } else {
      updateStep(
        'credentials', 
        'success', 
        'Credenciales válidas detectadas.', 
        `Proyecto: ${projectId} | API Key: ${maskString(apiKey)}`
      );
    }

    // --- TEST 2: SDK INIT ---
    if (!auth || !db) {
      updateStep(
        'sdk_init', 
        'error', 
        'Inicialización fallida.', 
        'La instancia de Auth o Firestore retornó null o undefined. Revisa src/firebase.ts.'
      );
      setIsRunningAll(false);
      return;
    } else {
      updateStep(
        'sdk_init', 
        'success', 
        'Instancias de Firebase SDK activas.', 
        'Firestore y Authentication se han inicializado correctamente en el cliente.'
      );
    }

    // --- TEST 3: AUTH CONNECTIVITY ---
    try {
      const currentUser = auth.currentUser;
      const userMessage = currentUser 
        ? `Sesión activa: ${currentUser.email} (UID: ${currentUser.uid})`
        : 'Listo para operar. No hay usuario autenticado (Modo Invitado)';
      
      updateStep(
        'auth_conn', 
        'success', 
        'Canal de autenticación en línea.', 
        userMessage
      );
    } catch (err: any) {
      updateStep(
        'auth_conn', 
        'error', 
        `Fallo al verificar el estado de Auth.`, 
        err.message
      );
    }

    // --- TEST 4: LATENCY AND PING ---
    const startTime = performance.now();
    try {
      // Use getDocFromServer to bypass local cache and enforce actual server communication
      const diagnosticRef = doc(db, 'usuarios', 'test_ping_network_nonexistent');
      await getDocFromServer(diagnosticRef).catch(() => {}); // catch error of nonexistent doc safely
      const endTime = performance.now();
      const latency = Math.round(endTime - startTime);

      updateStep(
        'network_ping', 
        'success', 
        `Conexión con Firestore establecida.`, 
        `Latencia de canal: ${latency}ms (Envío y recepción completados con éxito)`
      );
    } catch (err: any) {
      updateStep(
        'network_ping', 
        'error', 
        'No se pudo establecer canal remoto.', 
        `Error de conexión: ${err.message}. Asegúrate de tener conexión a internet.`
      );
    }

    // --- TEST 5: FIRESTORE READ PUBLIC ---
    try {
      const q = query(collection(db, 'usuarios'), limit(1));
      const querySnapshot = await getDocs(q);
      const docsCount = querySnapshot.size;
      
      updateStep(
        'fs_read_pub', 
        'success', 
        'Lectura de datos públicos verificada.', 
        `Colección /usuarios leída con éxito. Documentos retornados: ${docsCount}.`
      );
    } catch (err: any) {
      updateStep(
        'fs_read_pub', 
        'error', 
        'Denegado o error de red al consultar.', 
        `Error de Firestore: ${err.message}`
      );
    }

    // --- TEST 6: FIRESTORE WRITE DEV (Bypass Rule) ---
    const testDocId = 'demo_diagnostic_test';
    const testDocRef = doc(db, 'usuarios', testDocId);
    try {
      await setDoc(testDocRef, {
        name: 'NEXUS Diagnostic Node',
        role: 'Profesional',
        status: 'Activo',
        isDiagnosticTest: true,
        updatedAt: new Date()
      });

      updateStep(
        'fs_write_dev', 
        'success', 
        'Escritura de datos completada.', 
        `Escritura en /usuarios/${testDocId} autorizada por reglas de desarrollo ^demo_.*`
      );
    } catch (err: any) {
      updateStep(
        'fs_write_dev', 
        'error', 
        'Escritura rechazada por base de datos.', 
        `Detalles: ${err.message} (Code: ${err.code || 'unknown'})`
      );
    }

    // --- TEST 7: FIRESTORE DELETE ---
    try {
      await deleteDoc(testDocRef);
      updateStep(
        'fs_delete_dev', 
        'success', 
        'Baja de datos completada con éxito.', 
        `Documento de prueba /usuarios/${testDocId} purgado físicamente de Firestore.`
      );
    } catch (err: any) {
      updateStep(
        'fs_delete_dev', 
        'error', 
        'No se pudo eliminar el documento de prueba.', 
        `Detalles: ${err.message}`
      );
    }

    // --- TEST 8: SECURITY RULES BOUNDARY ---
    try {
      const restrictedQuery = query(collection(db, 'admins'), limit(1));
      await getDocs(restrictedQuery);
      
      // If this succeeds, it is a security leak!
      updateStep(
        'fs_security_rules', 
        'error', 
        'Alerta: ¡Datos restringidos legibles!', 
        'La colección /admins fue leída sin privilegios de administrador. Revisa tus firestore.rules.'
      );
    } catch (err: any) {
      if (err.code === 'permission-denied') {
        updateStep(
          'fs_security_rules', 
          'success', 
          'Blindaje de Seguridad Activo.', 
          'Lectura denegada en /admins (PERMISSION_DENIED). Las reglas protegieron la zona correctamente.'
        );
      } else {
        updateStep(
          'fs_security_rules', 
          'error', 
          'Error inesperado al probar reglas.', 
          `Error: ${err.message}`
        );
      }
    }

    setIsRunningAll(false);
  };

  const handleSeed = async () => {
    setIsSeeding(true);
    setSeedingStatus('Estableciendo conexión atómica...');
    try {
      const result = await seedDemoProfiles();
      if (result.success) {
        setSeedingStatus(`¡Éxito! Se inyectaron ${result.count} perfiles piloto en la base de datos.`);
        // Run diagnostics again to refresh statistics
        runDiagnostics();
      } else {
        setSeedingStatus(`Error al inyectar: ${result.error}`);
      }
    } catch (err: any) {
      setSeedingStatus(`Error crítico: ${err.message}`);
    } finally {
      setIsSeeding(false);
    }
  };

  // Get count of successful tests
  const successCount = results.filter(r => r.status === 'success').length;
  const errorCount = results.filter(r => r.status === 'error').length;
  const isHealthy = errorCount === 0;

  return (
    <div className="min-h-screen bg-[#080710] text-slate-100 flex flex-col items-center justify-center p-4 selection:bg-[#00FFFF]/20 selection:text-white">
      {/* Background Neon Glows */}
      <div className="absolute top-1/4 left-1/4 w-80 h-80 bg-cyan-500/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-violet-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="w-full max-w-2xl bg-black/80 border border-white/10 rounded-3xl p-6 md:p-8 shadow-2xl backdrop-blur-2xl relative overflow-hidden my-8">
        
        {/* Neon decorative top border */}
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_rgba(6,182,212,0.5)]" />

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-6 border-b border-white/5 select-none">
          <div>
            <div className="flex items-center gap-2">
              <Database className="w-5 h-5 text-cyan-400 animate-pulse" />
              <h1 className="text-xl font-black tracking-widest text-cyan-400 font-sans uppercase">SISTEMA_NEXUS</h1>
            </div>
            <p className="text-[10px] text-slate-400 uppercase tracking-[0.2em] mt-1">Diagnóstico Completo de Firebase & Firestore</p>
          </div>
          
          <div className="flex items-center gap-3 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-mono text-xs text-slate-300 tracking-wider font-semibold">{systemTime || 'Cargando...'}</span>
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400"></span>
            </span>
          </div>
        </div>

        {/* Auth Status Banner */}
        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
              <User className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Estado de Sesión</span>
              {sessionUser ? (
                <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                  Autenticado: <span className="font-mono text-slate-300">{sessionUser.email}</span>
                </span>
              ) : (
                <span className="text-xs font-bold text-amber-400">PWA Invitado (Sin autenticación)</span>
              )}
            </div>
          </div>
          <div className="text-xs">
            {sessionUser ? (
              <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-full font-black uppercase tracking-wider text-[9px]">
                Modo Profesional
              </span>
            ) : (
              <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2.5 py-1 rounded-full font-black uppercase tracking-wider text-[9px]">
                Acceso Público
              </span>
            )}
          </div>
        </div>

        {/* Diagnostics Summary Card */}
        <div className="grid grid-cols-3 gap-3 mb-6 select-none">
          <div className="bg-white/5 p-3 rounded-2xl border border-white/10 text-center">
            <span className="block text-[9px] uppercase text-slate-400 tracking-wider">Aprobados</span>
            <span className="text-2xl font-black text-emerald-400 mt-1 block">{successCount}</span>
          </div>
          <div className="bg-white/5 p-3 rounded-2xl border border-white/10 text-center">
            <span className="block text-[9px] uppercase text-slate-400 tracking-wider">Fallidos</span>
            <span className="text-2xl font-black text-rose-500 mt-1 block">{errorCount}</span>
          </div>
          <div className="bg-white/5 p-3 rounded-2xl border border-white/10 text-center">
            <span className="block text-[9px] uppercase text-slate-400 tracking-wider">Estado Global</span>
            <span className={`text-xs font-black mt-2.5 block uppercase tracking-widest ${isHealthy && successCount > 0 ? 'text-cyan-400' : 'text-rose-500'}`}>
              {isRunningAll ? 'Análisis...' : isHealthy && successCount > 0 ? '⚡ ÓPTIMO' : '🚨 REVISAR'}
            </span>
          </div>
        </div>

        {/* Diagnostic Steps Grid */}
        <div className="space-y-3">
          {results.map((step) => (
            <div 
              key={step.id}
              className={`p-4 rounded-2xl border transition-all duration-300 bg-[#0f0e1c] ${
                step.status === 'success' ? 'border-emerald-500/20 shadow-[0_0_15px_rgba(16,185,129,0.03)]' :
                step.status === 'error' ? 'border-rose-500/20 shadow-[0_0_15px_rgba(244,63,94,0.03)]' :
                'border-white/5'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-white/5 text-slate-400 border border-white/10 tracking-wider">
                      {step.category}
                    </span>
                    <h3 className="font-bold text-xs sm:text-sm text-slate-200">{step.name}</h3>
                  </div>
                  
                  <p className="text-xs text-slate-400 mt-1">{step.message}</p>
                  
                  {step.details && (
                    <div className="mt-2 p-2 rounded-lg bg-black/40 border border-white/5 text-[10px] font-mono text-slate-300 break-all select-all">
                      {step.details}
                    </div>
                  )}
                </div>

                <div className="shrink-0 pt-0.5">
                  {step.status === 'success' && (
                    <div className="flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider">
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Verde</span>
                    </div>
                  )}
                  {step.status === 'error' && (
                    <div className="flex items-center gap-1.5 bg-rose-500/10 text-rose-500 border border-rose-500/20 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider">
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Rojo</span>
                    </div>
                  )}
                  {step.status === 'loading' && (
                    <div className="flex items-center gap-1.5 bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider">
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Procesando</span>
                    </div>
                  )}
                  {step.status === 'idle' && (
                    <div className="flex items-center gap-1.5 bg-white/5 text-slate-500 border border-white/5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider">
                      <Play className="w-3 h-3" />
                      <span>Inactivo</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Diagnostic Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8">
          <button 
            onClick={runDiagnostics}
            disabled={isRunningAll}
            className="w-full h-11 rounded-2xl bg-white/5 hover:bg-white/10 active:scale-95 text-cyan-400 border border-cyan-500/20 hover:border-cyan-500/40 text-xs font-black tracking-widest uppercase transition-all flex items-center justify-center gap-2 shadow-lg shadow-cyan-950/10"
          >
            {isRunningAll ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Ejecutando Diagnóstico...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4" />
                Re-analizar Conexiones
              </>
            )}
          </button>

          <button 
            onClick={handleSeed}
            disabled={isSeeding || isRunningAll}
            className={`w-full h-11 rounded-2xl text-xs font-black tracking-widest uppercase transition-all flex items-center justify-center gap-2 shadow-lg ${
              isSeeding 
                ? 'bg-slate-800 text-slate-600 cursor-not-allowed border border-transparent' 
                : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white border border-white/10 hover:shadow-indigo-500/15'
            }`}
          >
            {isSeeding ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Inyectando...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Inyectar Datos Demo (PinPro v7)
              </>
            )}
          </button>
        </div>

        {seedingStatus && (
          <motion.div 
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            className={`mt-4 p-4 rounded-2xl border text-center font-mono text-[11px] leading-relaxed ${
              seedingStatus.includes('Error') 
                ? 'bg-rose-500/10 border-rose-500/20 text-rose-400' 
                : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
            }`}
          >
            {seedingStatus}
          </motion.div>
        )}

        {/* Footer info */}
        <div className="flex items-center justify-center gap-1.5 text-[9px] text-white/20 select-none uppercase tracking-[0.25em] mt-8 pointer-events-none text-center">
          <Server className="w-3.5 h-3.5 text-cyan-400/30" />
          <span>PinPro Secure Diagnostic Node — NEXUS Core v2.4</span>
        </div>
      </div>
    </div>
  );
};

export default FirebaseDiagnostic;

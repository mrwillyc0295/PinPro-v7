import React, { useEffect } from 'react';
import { usePinProWorker } from '../hooks/usePinProWorker';

// Datos de ejemplo simulando una respuesta masiva de Firebase
const mockFirebasePros = Array.from({ length: 1500 }, (_, i) => ({
  id: `pro_${i}`,
  name: `Profesional Técnico ${i}`,
  category: i % 2 === 0 ? 'plomeria' : 'electricidad',
  isVerified: i % 3 === 0,
  coordinates: {
    latitude: 10.9578 + (Math.random() - 0.5) * 0.1,
    longitude: -63.7997 + (Math.random() - 0.5) * 0.1
  }
}));

export const InteractiveMap: React.FC = () => {
  const { processedData, isProcessing, lastExecutionTime, dispatchGeoQuery } = usePinProWorker();

  const handleUserMovement = () => {
    const currentPayload = {
      taskId: 'task_geo_98745',
      prefetchRadiusMeters: 5000,
      activeFilters: ['verified_pro'],
      coordinates: { latitude: 10.9578, longitude: -63.7997 }
    };

    // Ejecuta el razonamiento en segundo plano sin congelar los clicks del usuario
    dispatchGeoQuery(currentPayload, mockFirebasePros);
  };

  return (
    <div className="p-6 bg-slate-950 text-white min-h-screen">
      <h2 className="text-2xl font-bold text-cyan-400">Panel de Control PinPro</h2>
      <p className="text-xs text-purple-400 mb-4">Motor de Rendimiento Activo</p>

      <button 
        onClick={handleUserMovement}
        className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-lg font-semibold hover:opacity-90 transition-all"
      >
        Simular Escaneo Geo-Posicional
      </button>

      {isProcessing ? (
        // Skeleton Fallback óptimo para simular carga instantánea
        <div className="mt-6 animate-pulse space-y-3">
          <div className="h-4 bg-slate-800 rounded w-3/4"></div>
          <div className="h-32 bg-slate-800 rounded-lg"></div>
        </div>
      ) : (
        <div className="mt-6">
          <p className="text-sm text-emerald-400 mb-2">
            Resultados procesados en: <strong>{lastExecutionTime}ms</strong>
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {processedData.slice(0, 4).map(pro => (
              <div key={pro.id} className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
                <h4 className="text-cyan-300 font-medium">{pro.name}</h4>
                <p className="text-xs text-slate-400">Categoría: {pro.category}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

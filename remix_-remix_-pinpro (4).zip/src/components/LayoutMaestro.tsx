import React, { ReactNode } from 'react';

interface LayoutMaestroProps {
  children: ReactNode;
}

export default function LayoutMaestro({ children }: LayoutMaestroProps) {
  return (
    // min-h-[100dvh] es el secreto para que no se corte en el iPhone
    <div className="w-full min-h-[100dvh] bg-neutral-950 text-white overflow-x-hidden selection:bg-cyan-500/30">
      
      {/* Contenedor central que limita el ancho en pantallas gigantes, 
          pero usa el 100% en móviles y tablets */}
      <main className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-safe flex flex-col items-center justify-start">
        {children}
      </main>

    </div>
  );
}

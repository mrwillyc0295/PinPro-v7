import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Download, X } from 'lucide-react';

export default function AvisoInstalacion() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showAviso, setShowAviso] = useState(false);

  useEffect(() => {
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      // Solo mostrar si no ha sido instalada o rechazada recientemente
      const lastDismissed = localStorage.getItem('pwa_prompt_dismissed');
      const now = Date.now();
      
      if (!lastDismissed || now - parseInt(lastDismissed) > 86400000) { // 24h
        setShowAviso(true);
      }
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  const handleInstalar = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setShowAviso(false);
    }
    setDeferredPrompt(null);
  };

  const handleDismiss = () => {
    setShowAviso(false);
    localStorage.setItem('pwa_prompt_dismissed', Date.now().toString());
  };

  return (
    <AnimatePresence>
      {showAviso && (
        <motion.div 
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-24 left-4 right-4 z-50"
        >
          <div className="bg-[#111c22] border border-[#00FFFF]/30 p-4 rounded-2xl shadow-[0_0_30px_rgba(0,255,255,0.15)] backdrop-blur-md flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#00FFFF]/10 rounded-xl flex items-center justify-center">
                <Download className="w-5 h-5 text-[#00FFFF]" />
              </div>
              <div>
                <p className="text-white font-bold text-sm">Instala PinPro PWA</p>
                <p className="text-white/60 text-[10px] leading-tight">Mejor precisión GPS y alertas en tiempo real.</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <button 
                onClick={handleInstalar}
                className="bg-[#00FFFF] text-black px-4 py-2 rounded-lg font-black text-xs hover:scale-105 transition-transform"
              >
                INSTALAR
              </button>
              <button 
                onClick={handleDismiss}
                className="p-2 text-white/40 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

import React, { ReactNode } from 'react';
import ErrorBoundary from './ErrorBoundary';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  componentName?: string;
}

export const SafeBoundary: React.FC<Props> = ({ children, fallback }) => {
  return (
    <ErrorBoundary>
      {children || fallback}
    </ErrorBoundary>
  );
};


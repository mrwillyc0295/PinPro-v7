import { useState, useEffect, useRef } from 'react';
import { calculatePreciseDistance, isValidServiceArea } from '../lib/gisServices';

interface GeoConfig {
  minDistanceMeters?: number; // Mínimo de metros movidos antes de enviar actualización
  minTimeSeconds?: number;    // Frecuencia máxima en segundos incluso si no se mueve
  enableHighAccuracy?: boolean;
}

export function useSmartGeolocation({
  minDistanceMeters = 50,
  minTimeSeconds = 60,
  enableHighAccuracy = true
}: GeoConfig = {}) {
  const [location, setLocation] = useState<[number, number] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isOutOfArea, setIsOutOfArea] = useState(false);

  const lastUpdateTime = useRef<number>(0);
  const lastLocation = useRef<[number, number] | null>(null);

  useEffect(() => {
    if (!navigator.geolocation) {
      setError('Geolocalización no soportada por el navegador.');
      return;
    }

    const watchId = navigator.geolocation.watchPosition(
      (position) => {
        const currentLoc: [number, number] = [
          position.coords.latitude, 
          position.coords.longitude
        ];

        // 1. Validar restricción geográfica (LATAM / ESPAÑA)
        if (!isValidServiceArea(currentLoc[0], currentLoc[1])) {
          setIsOutOfArea(true);
          setError('El servicio de PinPro no está disponible en tu región actual.');
          return;
        }
        
        setIsOutOfArea(false);

        const now = Date.now();
        const timeDiffSeconds = (now - lastUpdateTime.current) / 1000;
        
        let shouldUpdate = false;

        // 2. Lógica de "Thresholds" (Debounce espacial/temporal) para ahorrar batería
        if (!lastLocation.current) {
          shouldUpdate = true; // Primera lectura
        } else {
          const movedDistanceKm = calculatePreciseDistance(lastLocation.current, currentLoc);
          const movedDistanceMeters = movedDistanceKm * 1000;

          // Refresca si se movió más de la distancia mínima (ej. 50 metros) 
          // O si superó el tiempo límite (ej. 60 segundos buscando señal)
          if (movedDistanceMeters >= minDistanceMeters || timeDiffSeconds >= minTimeSeconds) {
            shouldUpdate = true;
          }
        }

        if (shouldUpdate) {
          setLocation(currentLoc);
          lastLocation.current = currentLoc;
          lastUpdateTime.current = now;
          setError(null);
          
          // Aquí: Emitimos evento real a Firebase o contexto (Simulado para que no quiebre)
          console.log(`[SmartGeo] Ubicación actualizada: ${currentLoc[0]}, ${currentLoc[1]}`);
        }
      },
      (err) => {
        setError(`Error GPS: ${err.message}`);
      },
      {
        enableHighAccuracy,
        maximumAge: 0,
        timeout: 10000
      }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [minDistanceMeters, minTimeSeconds, enableHighAccuracy]);

  return { location, error, isOutOfArea };
}

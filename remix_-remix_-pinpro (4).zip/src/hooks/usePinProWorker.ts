import { useEffect, useRef, useState } from 'react';

export const usePinProWorker = () => {
  const [processedData, setProcessedData] = useState<any[]>([]);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [lastExecutionTime, setLastExecutionTime] = useState<number>(0);
  const workerRef = useRef<Worker | null>(null);

  useEffect(() => {
    // Inicializar el Web Worker de manera segura para PWAs
    workerRef.current = new Worker(
      new URL('../workers/pinpro.worker.ts', import.meta.url),
      { type: 'module' }
    );

    // Capturar la respuesta optimizada del Worker
    workerRef.current.onmessage = (event: MessageEvent) => {
      const { status, data, executionTimeMs } = event.data;
      if (status === 'success') {
        setProcessedData(data);
        setLastExecutionTime(executionTimeMs);
        setIsProcessing(false);
      }
    };

    return () => {
      workerRef.current?.terminate();
    };
  }, []);

  const debounceTimer = useRef<NodeJS.Timeout | null>(null);

  const dispatchGeoQuery = (payload: any, databasePros: any[]) => {
    if (debounceTimer.current) clearTimeout(debounceTimer.current);

    debounceTimer.current = setTimeout(() => {
      setIsProcessing(true);
      workerRef.current?.postMessage({
        type: 'PROCESS_GEO_QUEUE',
        payload,
        databasePros
      });
    }, 300); // 300ms debounce for high-performance interaction
  };

  return {
    processedData,
    isProcessing,
    lastExecutionTime,
    dispatchGeoQuery
  };
};

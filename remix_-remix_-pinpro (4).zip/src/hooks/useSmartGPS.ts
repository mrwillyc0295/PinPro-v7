import { useEffect, useRef, useState } from 'react';

interface LocationData {
  latitude: number;
  longitude: number;
  speed: number | null;
}

export const useSmartGPS = (onLocationChange: (location: LocationData) => void) => {
  const [currentLocation, setCurrentLocation] = useState<LocationData | null>(null);
  const watchIdRef = useRef<number | null>(null);
  const lastPingTimeRef = useRef<number>(0);

  // Configuración dinámica de tráfico según el estado del usuario
  const getDynamicInterval = (speed: number | null): number => {
    if (!speed || speed < 1) return 30000; // Estático: 30 segundos
    if (speed < 10) return 10000;          // Velocidad baja (caminando): 10 segundos
    return 5000;                           // Velocidad alta (vehículo): 5 segundos
  };

  useEffect(() => {
    if (!navigator.geolocation) {
      console.error('Geolocalización no soportada por este navegador.');
      return;
    }

    // Monitorear el GPS en tiempo real con alta precisión
    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        const { latitude, longitude, speed } = position.coords;
        const now = Date.now();
        const dynamicInterval = getDynamicInterval(speed);

        // CONTROL DE TRÁFICO: Solo emitir el cambio si se cumplió el intervalo dinámico
        if (now - lastPingTimeRef.current >= dynamicInterval) {
          const newLocation = { latitude, longitude, speed };
          setCurrentLocation(newLocation);
          onLocationChange(newLocation);
          
          lastPingTimeRef.current = now; // Actualizar marca de tiempo del último ping
        }
      },
      (error) => console.error('Error de GPS:', error),
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );

    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, [onLocationChange]);

  return { currentLocation };
};

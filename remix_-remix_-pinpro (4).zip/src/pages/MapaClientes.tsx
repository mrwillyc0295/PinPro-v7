import { useEffect, useState } from 'react';
import { escucharMapaProfesionales, MarcadorProfesional } from '../services/logicaMapa';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Star, Shield, Smartphone, Zap } from 'lucide-react';

export default function MapaClientes() {
  const [profesionalesEnMapa, setProfesionalesEnMapa] = useState<MarcadorProfesional[]>([]);
  const [mapCenter] = useState<[number, number]>([10.2117, -64.6735]); // Lechería native origin

  useEffect(() => {
    // Nos suscribimos a los cambios en vivo de la base de datos al montar el componente
    const desuscribir = escucharMapaProfesionales((nuevosPuntos) => {
      setProfesionalesEnMapa(nuevosPuntos);
    });

    // Limpiamos la conexión cuando el usuario sale de la pantalla del mapa
    return () => desuscribir();
  }, []);

  // Helper to construct highly polished neon-LED marker icons using L.divIcon
  const getProIcon = (categoria: string) => {
    return L.divIcon({
      className: "custom-pro-marker-neon bg-transparent border-none animate-pulse",
      html: `
        <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 40px; height: 40px;">
          <div style="position: absolute; width: 40px; height: 40px; background-color: rgba(0, 255, 255, 0.2); border: 2.5px solid #00FFFF; border-radius: 50%; box-shadow: 0 0 15px #00FFFF, inset 0 0 10px #00FFFF; animation: ping 2s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
          <div style="position: relative; width: 30px; height: 30px; background-color: #0d0d0d; border: 2px solid #00FFFF; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 10px #00FFFF; color: #00FFFF; font-size: 13px; font-weight: bold;">
            ${categoria.substring(0, 2).toUpperCase()}
          </div>
        </div>
      `,
      iconSize: [40, 40],
      iconAnchor: [20, 20],
      popupAnchor: [0, -20]
    });
  };

  return (
    <div className="relative w-full h-screen bg-neutral-950">
      {/* Contenedor del Mapa */}
      <div id="map" className="w-full h-full z-10">
        <MapContainer 
          center={mapCenter} 
          zoom={13} 
          style={{ width: '100%', height: '100%' }}
          preferCanvas={true}
        >
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          />

          {profesionalesEnMapa.map((pro) => (
            <Marker 
              key={pro.id} 
              position={[pro.lat, pro.lng]} 
              icon={getProIcon(pro.categoria)}
            >
              <Popup className="premium-map-popup">
                <div className="bg-[#0b0c10] text-white p-3 rounded-xl border border-cyan-500/30 max-w-xs font-sans">
                  <div className="flex items-center justify-between mb-1.5 border-b border-cyan-500/20 pb-1.5">
                    <span className="text-[10px] bg-cyan-500/10 text-[#00FFFF] px-2 py-0.5 rounded-full font-mono font-bold border border-cyan-500/20">
                      {pro.categoria}
                    </span>
                    <span className="text-[10px] text-gray-400 font-mono">
                      Ref: {pro.id.substring(0, 6).toUpperCase()}
                    </span>
                  </div>

                  <h4 className="font-black text-sm text-white tracking-tight uppercase italic">{pro.nombre}</h4>
                  
                  {pro.especialidad && (
                    <p className="text-xs text-cyan-400/80 mt-1 font-medium">{pro.especialidad}</p>
                  )}

                  <div className="flex items-center justify-between mt-3 bg-white/5 p-2 rounded-lg border border-white/5">
                    <div>
                      <p className="text-[9px] text-gray-400 uppercase font-bold tracking-wider">Tarifa</p>
                      <p className="text-xs font-bold text-white">${pro.tarifa}/h</p>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-[9px] text-gray-400 uppercase font-bold tracking-wider">Rating</p>
                      <div className="flex items-center gap-1 text-xs font-bold text-yellow-400">
                        <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        <span>{pro.rating.toFixed(1)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-2 text-center">
                    <span className="text-[9px] text-green-400 font-mono flex items-center justify-center gap-1">
                      <Zap className="w-2.5 h-2.5 animate-bounce" /> EN LÍNEA & TRANSMITIENDO GPS
                    </span>
                  </div>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>

      {/* Superposición UI: Contador Flotante estilo Glassmorphism */}
      <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md border border-white/10 px-4 py-3 rounded-2xl text-white font-mono text-xs shadow-[0_4px_30px_rgba(0,0,0,0.5)] z-20 flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse"></div>
          <span className="text-white font-bold">MONITOR EN TIEMPO REAL</span>
        </div>
        <div className="text-[10px] text-gray-400 mt-1">
          Expertos activos: <span className="text-[#00FFFF] font-bold font-sans text-xs animate-pulse ml-0.5">{profesionalesEnMapa.length}</span>
        </div>
      </div>
    </div>
  );
}

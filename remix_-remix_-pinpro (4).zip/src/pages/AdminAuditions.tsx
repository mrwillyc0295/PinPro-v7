import React, { useState, useEffect } from 'react';
import { 
  ClipboardCheck, 
  Search, 
  Filter, 
  CheckCircle, 
  XCircle, 
  Clock, 
  User, 
  ArrowLeft, 
  Eye, 
  MoreVertical,
  ShieldCheck,
  Star,
  FileText,
  AlertCircle,
  Download
} from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  collection, 
  onSnapshot, 
  doc, 
  updateDoc, 
  addDoc, 
  serverTimestamp, 
  query, 
  where,
  runTransaction,
  limit
} from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { cn } from '../lib/utils';
import { Helmet } from 'react-helmet-async';

interface AuditionRecord {
  id: string;
  proId: string;
  proName: string;
  auditorId: string;
  status: 'pending' | 'approved' | 'rejected';
  notes?: string;
  score?: number;
  createdAt: any;
  updatedAt?: any;
}

interface ProUser {
  uid: string;
  name: string;
  profession?: string;
  verificationStatus?: string;
  auditionStatus?: string;
  email?: string;
  photoUrl?: string;
}

export default function AdminAuditions() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [auditions, setAuditions] = useState<AuditionRecord[]>([]);
  const [pros, setPros] = useState<ProUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAudition, setSelectedAudition] = useState<AuditionRecord | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewJsonOpen, setIsViewJsonOpen] = useState(false);
  
  // Form State
  const [formNotes, setFormNotes] = useState('');
  const [formScore, setFormScore] = useState(100);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    // Subscribe to auditions
    const unsubscribeAuditions = onSnapshot(collection(db, 'auditions'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AuditionRecord));
      setAuditions(data);
    });

    // Subscribe to professionals needing audition
    const q = query(collection(db, 'profesionales'), limit(100));
    const unsubscribePros = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as ProUser));
      setPros(data);
      setLoading(false);
    });

    return () => {
      unsubscribeAuditions();
      unsubscribePros();
    };
  }, []);

  const handleApprove = async (audition: AuditionRecord) => {
    if (!window.confirm(`¿Estás seguro de APROBAR la audición de ${audition.proName}?`)) return;
    
    setIsSubmitting(true);
    try {
      // Implement the transaction logic provided by the user conceptually
      await runTransaction(db, async (transaction) => {
        const auditionRef = doc(db, 'auditions', audition.id);
        const proRef = doc(db, 'profesionales', audition.proId);

        transaction.update(auditionRef, {
          status: 'approved',
          notes: formNotes || 'Aprobado mediante revisión administrativa.',
          score: formScore,
          auditorId: user?.uid,
          updatedAt: serverTimestamp()
        });

        transaction.update(proRef, {
          auditionStatus: 'approved',
          verificationStatus: 'verified',
          verified: true, // Legacy field
          trustBoost: 50, // Standard trust boost
          updatedAt: serverTimestamp()
        });
      });

      alert('✅ Audición aprobada con éxito. El profesional ahora está verificado.');
      setIsModalOpen(false);
    } catch (error) {
      console.error("Error approving audition:", error);
      alert('Error al aprobar la audición.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReject = async (audition: AuditionRecord) => {
    if (!window.confirm(`¿Estás seguro de RECHAZAR la audición de ${audition.proName}?`)) return;
    
    setIsSubmitting(true);
    try {
      await runTransaction(db, async (transaction) => {
        const auditionRef = doc(db, 'auditions', audition.id);
        const proRef = doc(db, 'profesionales', audition.proId);

        transaction.update(auditionRef, {
          status: 'rejected',
          notes: formNotes || 'Rechazado en revisión administrativa.',
          auditorId: user?.uid,
          updatedAt: serverTimestamp()
        });

        transaction.update(proRef, {
          auditionStatus: 'rejected',
          verificationStatus: 'rejected',
          updatedAt: serverTimestamp()
        });
      });

      alert('❌ Audición rechazada.');
      setIsModalOpen(false);
    } catch (error) {
      console.error("Error rejecting audition:", error);
      alert('Error al procesar el rechazo.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const openAuditModal = (audition: AuditionRecord) => {
    setSelectedAudition(audition);
    setFormNotes(audition.notes || '');
    setFormScore(audition.score || 100);
    setIsModalOpen(true);
  };

  const createAuditionForPro = async (pro: ProUser) => {
    try {
      const existing = auditions.find(a => a.proId === pro.uid && a.status === 'pending');
      if (existing) {
        openAuditModal(existing);
        return;
      }

      const newAudition = {
        proId: pro.uid,
        proName: pro.name,
        status: 'pending',
        createdAt: serverTimestamp(),
        auditorId: user?.uid || 'system'
      };

      const docRef = await addDoc(collection(db, 'auditions'), newAudition);
      alert('✅ Solicitud de audición creada para el profesional.');
    } catch (error) {
      console.error("Error creating audition:", error);
      alert('Error al crear la solicitud de audición.');
    }
  };

  const filteredAuditions = auditions.filter(a => 
    a.proName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const pendingPros = pros.filter(p => 
    p.verificationStatus === 'pending' || 
    (p.auditionStatus !== 'approved' && !auditions.some(a => a.proId === p.uid && a.status === 'approved'))
  ).filter(p => p.name?.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="min-h-screen bg-[#050505] text-white flex flex-col font-sans pb-20">
      <Helmet>
        <title>Gestión de Audiciones | Admin PinPro</title>
      </Helmet>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#0a0a0a]/80 backdrop-blur-xl border-b border-white/5 px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/admin" className="p-2 hover:bg-white/5 rounded-xl transition-colors">
            <ArrowLeft className="w-5 h-5 text-white/60" />
          </Link>
          <div>
            <h1 className="text-xl font-black uppercase italic tracking-tighter">Audiciones PinPro</h1>
            <p className="text-[10px] text-orange-400 font-mono tracking-widest uppercase">Verification Engine v2.1</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-orange-500/10 border border-orange-500/20 px-3 py-1.5 rounded-full">
          <Clock className="w-3.5 h-3.5 text-orange-400" />
          <span className="text-[10px] font-black text-orange-400 uppercase tracking-widest">
            {auditions.filter(a => a.status === 'pending').length} PENDIENTES
          </span>
        </div>
      </header>

      <main className="flex-1 p-6 space-y-8 max-w-5xl mx-auto w-full">
        
        {/* Search Bar */}
        <div className="relative group">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-white/20 group-focus-within:text-orange-400 transition-colors" />
          <input 
            type="text"
            placeholder="Buscar por nombre, estado o ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-3xl py-5 pl-14 pr-6 text-sm focus:outline-none focus:border-orange-500/50 transition-all placeholder:text-white/20 shadow-inner"
          />
        </div>

        {/* Pending Professionals Section */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase text-white/40 tracking-[0.2em] flex items-center gap-2">
              <User className="w-4 h-4" /> Pros por Audicionar
            </h3>
            <span className="text-[10px] text-white/20 font-bold">{pendingPros.length} ENCONTRADOS</span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pendingPros.length > 0 ? (
              pendingPros.map(pro => (
                <div key={pro.uid} className="bg-white/5 border border-white/10 p-5 rounded-[28px] flex items-center justify-between hover:border-white/20 transition-all group">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-white/10 overflow-hidden border border-white/5">
                      <img 
                        src={pro.photoUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${pro.uid}`} 
                        alt="Pro" 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="font-black text-sm uppercase italic leading-tight">{pro.name}</h4>
                      <p className="text-[9px] text-orange-400 font-bold uppercase tracking-widest mt-1">{pro.profession || 'Especialista'}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => createAuditionForPro(pro)}
                    className="p-3 bg-orange-500 text-black rounded-2xl hover:scale-105 active:scale-95 transition-all shadow-[0_0_15px_rgba(249,115,22,0.3)]"
                  >
                    <ClipboardCheck className="w-5 h-5" />
                  </button>
                </div>
              ))
            ) : (
              <div className="col-span-full py-8 text-center bg-white/5 rounded-[32px] border border-dashed border-white/10 text-white/20 text-xs uppercase font-bold italic tracking-widest">
                No hay profesionales pendientes de audición
              </div>
            )}
          </div>
        </section>

        {/* Audition History Section */}
        <section className="space-y-4">
          <h3 className="text-xs font-black uppercase text-white/40 tracking-[0.2em] flex items-center gap-2">
            <FileText className="w-4 h-4" /> Historial de Audiciones
          </h3>
          
          <div className="space-y-3">
            {filteredAuditions.length > 0 ? (
              filteredAuditions.map(audition => (
                <div key={audition.id} className="bg-[#111111] border border-white/5 rounded-3xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-12 h-12 rounded-2xl flex items-center justify-center border",
                      audition.status === 'approved' ? "bg-green-500/10 border-green-500/20" : 
                      audition.status === 'rejected' ? "bg-red-500/10 border-red-500/20" : 
                      "bg-orange-500/10 border-orange-500/20"
                    )}>
                      {audition.status === 'approved' ? <CheckCircle className="w-6 h-6 text-green-500" /> : 
                       audition.status === 'rejected' ? <XCircle className="w-6 h-6 text-red-500" /> : 
                       <Clock className="w-6 h-6 text-orange-500 animate-pulse" />}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-black text-sm uppercase italic">{audition.proName}</h4>
                        <span className={cn(
                          "text-[8px] font-black uppercase px-2 py-0.5 rounded-full border",
                          audition.status === 'approved' ? "bg-green-500/10 text-green-400 border-green-500/30" : 
                          audition.status === 'rejected' ? "bg-red-500/10 text-red-400 border-red-500/30" : 
                          "bg-orange-500/10 text-orange-400 border-orange-500/30"
                        )}>
                          {audition.status}
                        </span>
                      </div>
                      <p className="text-[9px] text-white/20 font-mono mt-1">ID: {audition.id.slice(-8).toUpperCase()} • {new Date(audition.createdAt?.seconds * 1000).toLocaleDateString()}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => {
                        setSelectedAudition(audition);
                        setIsViewJsonOpen(true);
                      }}
                      className="p-2.5 bg-white/5 text-white/40 hover:text-white rounded-xl transition-all"
                      title="Ver JSON"
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                    {audition.status === 'pending' && (
                      <button 
                        onClick={() => openAuditModal(audition)}
                        className="bg-white/10 hover:bg-white/20 text-white font-black text-[10px] uppercase tracking-widest px-6 py-3 rounded-2xl transition-all"
                      >
                        Auditar
                      </button>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="py-20 text-center text-white/20">
                No se encontraron registros de audiciones.
              </div>
            )}
          </div>
        </section>
      </main>

      {/* Audit Modal */}
      <AnimatePresence>
        {isModalOpen && selectedAudition && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/90 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-[#111111] border border-white/10 rounded-[40px] p-8 shadow-3xl overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-8 opacity-5">
                <ShieldCheck className="w-32 h-32 text-orange-400" />
              </div>

              <div className="relative space-y-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-orange-500/10 rounded-3xl flex items-center justify-center mx-auto border border-orange-500/20 mb-4">
                    <ClipboardCheck className="w-8 h-8 text-orange-400" />
                  </div>
                  <h3 className="text-2xl font-black uppercase italic tracking-tighter">Panel de Auditoría</h3>
                  <p className="text-white/40 text-sm mt-1">Evaluando a {selectedAudition.proName}</p>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-white/40 tracking-widest ml-1">Calificación de Calidad (0-100)</label>
                    <div className="flex items-center gap-4">
                      <input 
                        type="range" 
                        min="0" 
                        max="100" 
                        value={formScore}
                        onChange={(e) => setFormScore(parseInt(e.target.value))}
                        className="flex-1 accent-orange-500"
                      />
                      <span className="text-xl font-black text-orange-400 w-12 text-right">{formScore}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-white/40 tracking-widest ml-1">Notas de la Auditoría</label>
                    <textarea 
                      value={formNotes}
                      onChange={(e) => setFormNotes(e.target.value)}
                      placeholder="Describe el desempeño o razones de la decisión..."
                      className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 h-32 focus:outline-none focus:border-orange-500/50 transition-all text-sm resize-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4">
                  <button 
                    onClick={() => handleReject(selectedAudition)}
                    disabled={isSubmitting}
                    className="py-4 bg-red-500/10 text-red-500 border border-red-500/20 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all disabled:opacity-50"
                  >
                    Rechazar
                  </button>
                  <button 
                    onClick={() => handleApprove(selectedAudition)}
                    disabled={isSubmitting}
                    className="py-4 bg-green-500 text-black rounded-2xl font-black text-xs uppercase tracking-widest shadow-[0_0_20px_rgba(34,197,94,0.3)] hover:scale-105 active:scale-95 transition-all disabled:opacity-50"
                  >
                    {isSubmitting ? 'Procesando...' : 'Aprobar Pro'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* JSON Viewer Modal */}
      <AnimatePresence>
        {isViewJsonOpen && selectedAudition && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsViewJsonOpen(false)}
              className="absolute inset-0 bg-black/95 backdrop-blur-xl"
            />
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              className="relative w-full max-w-2xl bg-[#0a0a0a] border border-white/10 rounded-[32px] overflow-hidden flex flex-col max-h-[80vh]"
            >
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-blue-500/10 rounded-lg flex items-center justify-center border border-blue-500/20">
                    <FileText className="w-4 h-4 text-blue-500" />
                  </div>
                  <h3 className="font-black uppercase italic tracking-tighter">Audition Data JSON</h3>
                </div>
                <button onClick={() => setIsViewJsonOpen(false)} className="text-white/40 hover:text-white">
                  <XCircle className="w-6 h-6" />
                </button>
              </div>
              <div className="flex-1 overflow-auto p-6 font-mono text-xs bg-black selection:bg-blue-500 selection:text-white">
                <pre className="text-blue-400">
                  {JSON.stringify(selectedAudition, null, 2)}
                </pre>
              </div>
              <div className="p-4 bg-[#111111] border-t border-white/5 flex justify-end gap-3">
                <button 
                  onClick={() => {
                    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(selectedAudition, null, 2));
                    const downloadAnchorNode = document.createElement('a');
                    downloadAnchorNode.setAttribute("href", dataStr);
                    downloadAnchorNode.setAttribute("download", `audition_${selectedAudition.id}.json`);
                    document.body.appendChild(downloadAnchorNode);
                    downloadAnchorNode.click();
                    downloadAnchorNode.remove();
                  }}
                  className="flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                >
                  <Download className="w-4 h-4" /> Exportar .JSON
                </button>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(JSON.stringify(selectedAudition, null, 2));
                    alert('JSON copiado al portapapeles');
                  }}
                  className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                >
                   Copiar Código
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { motion } from 'motion/react';
import { ShieldAlert, CheckCircle, Clock, Video, HelpCircle, ArrowLeft, LogOut, CheckCircle2, AlertCircle } from 'lucide-react';
import { auth } from '../firebase';
import { signOut } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';

export default function AudicionRevision() {
  const { profile, handleNavigateWithTelemetry } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      handleNavigateWithTelemetry(window.location.pathname, '/login', navigate);
    } catch (err) {
      console.error("Error signing out:", err);
    }
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'incomplete':
        return {
          title: 'Audición Incompleta',
          color: 'text-amber-500 border-amber-500/20 bg-amber-500/10',
          icon: <AlertCircle className="w-8 h-8 text-amber-500" />,
          desc: 'Aún no has enviado tu video de audición y tarifa por hora.',
        };
      case 'pending':
        return {
          title: 'Audición en Evaluación',
          color: 'text-[#00FFFF] border-[#00FFFF]/20 bg-[#00FFFF]/5',
          icon: <Clock className="w-8 h-8 text-[#00FFFF] animate-pulse" />,
          desc: 'Nuestro comité está evaluando tu portafolio y video para garantizar el estándar élite de PinPro.',
        };
      case 'approved':
        return {
          title: 'Audición Aprobada',
          color: 'text-[#00dc82] border-[#00dc82]/20 bg-[#00dc82]/10',
          icon: <CheckCircle className="w-8 h-8 text-[#00dc82]" />,
          desc: '¡Excelente! Tu audición ha sido aprobada por la comunidad.',
        };
      default:
        return {
          title: 'Estado Desconocido',
          color: 'text-gray-400 border-gray-400/20 bg-gray-400/10',
          icon: <HelpCircle className="w-8 h-8 text-gray-400" />,
          desc: 'Tu estado está bajo validación adicional.',
        };
    }
  };

  const auditionStatus = profile?.auditionStatus || 'pending';
  const isVerified = !!profile?.verified;
  const statusConfig = getStatusConfig(auditionStatus);

  // Custom pre-filled WhatsApp message for support
  const supportUrl = `https://wa.me/18092244199?text=${encodeURIComponent(
    `Hola PinPro Support, soy el profesional ${profile?.name || ''} (UID: ${profile?.uid || ''}). Deseo consultar el estado de mi audición y verificación de identidad.`
  )}`;

  return (
    <div className="flex flex-col min-h-[100dvh] bg-black relative max-w-md mx-auto border-x border-white/10 overflow-hidden text-white font-sans">
      {/* Immersive Cyberpunk Grid Background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none"></div>

      {/* Cyberpunk ambient glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-72 h-72 bg-[#B026FF]/10 blur-[100px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-10 left-10 w-48 h-48 bg-[#00FFFF]/15 blur-[80px] rounded-full pointer-events-none"></div>

      <div className="relative z-10 flex-1 flex flex-col justify-between px-6 pt-12 pb-8">
        
        {/* Header with Exit controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 select-none">
            <span className="text-[10px] font-black tracking-[0.4em] text-white/40 uppercase">SISTEMA PINPRO</span>
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping"></span>
          </div>
          <button
            onClick={handleSignOut}
            className="flex items-center gap-2 bg-white/5 hover:bg-red-500/10 border border-white/10 hover:border-red-500/20 px-3 py-1.5 rounded-xl text-xs font-bold tracking-wider transition-all uppercase cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Cerrar Sesión</span>
          </button>
        </div>

        {/* Core Glassmorphic Status Box */}
        <div className="my-auto py-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ type: 'spring', damping: 20 }}
            className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-[32px] p-6 shadow-[0_0_50px_rgba(0,0,0,0.8)] relative overflow-hidden"
          >
            {/* Top scanning line decorative neon accent */}
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#00FFFF] to-transparent animate-pulse"></div>

            <div className="flex flex-col items-center text-center">
              {/* Icon Container with glowing effects */}
              <div className="w-16 h-16 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-center mb-5 shadow-[0_0_30px_rgba(0,0,0,0.5)]">
                {statusConfig.icon}
              </div>

              <h2 className="text-2xl font-black uppercase tracking-tight mb-2">
                Audición en <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00FFFF] to-[#B026FF]">Revisión</span>
              </h2>

              <p className="text-white/60 text-xs px-2 leading-relaxed mb-6 font-medium">
                {statusConfig.desc}
              </p>

              {/* Status Tracker Grid */}
              <div className="w-full space-y-3 bg-black/40 border border-white/5 p-4 rounded-2xl text-left">
                <div className="text-[9px] font-black uppercase tracking-widest text-white/30 border-b border-white/5 pb-2 mb-1">
                  ESTADO DE MILÉSTONAS
                </div>

                {/* Milestone 1: Formulario */}
                <div className="flex items-center justify-between text-xs font-semibold py-1">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-4.5 h-4.5 text-[#00dc82]" />
                    <span className="text-white/80">Perfil e Información de Pago</span>
                  </div>
                  <span className="text-[9px] bg-[#00dc82]/10 text-[#00dc82] px-2 py-0.5 rounded-full uppercase font-bold tracking-wider">COMPLETADO</span>
                </div>

                {/* Milestone 2: Audition Video */}
                <div className="flex items-center justify-between text-xs font-semibold py-1">
                  <div className="flex items-center gap-2.5">
                    {auditionStatus === 'approved' ? (
                      <CheckCircle2 className="w-4.5 h-4.5 text-[#00dc82]" />
                    ) : (
                      <Clock className="w-4.5 h-4.5 text-amber-500 animate-pulse" />
                    )}
                    <span className="text-white/80">Audición de Talento (Video)</span>
                  </div>
                  <span className={`text-[9px] px-2 py-0.5 rounded-full uppercase font-bold tracking-wider ${
                    auditionStatus === 'approved'
                      ? 'bg-[#00dc82]/10 text-[#00dc82]'
                      : 'bg-amber-500/10 text-amber-500'
                  }`}>
                    {auditionStatus === 'approved' ? 'APROBADA' : 'PENDIENTE'}
                  </span>
                </div>

                {/* Milestone 3: Identity Verification */}
                <div className="flex items-center justify-between text-xs font-semibold py-1">
                  <div className="flex items-center gap-2.5">
                    {isVerified ? (
                      <CheckCircle2 className="w-4.5 h-4.5 text-[#00dc82]" />
                    ) : (
                      <ShieldAlert className="w-4.5 h-4.5 text-amber-500" />
                    )}
                    <span className="text-white/80">Verificación de Identidad</span>
                  </div>
                  <span className={`text-[9px] px-2 py-0.5 rounded-full uppercase font-bold tracking-wider ${
                    isVerified
                      ? 'bg-[#00dc82]/10 text-[#00dc82]'
                      : 'bg-amber-500/10 text-amber-500'
                  }`}>
                    {isVerified ? 'VERIFICADO' : 'PENDIENTE'}
                  </span>
                </div>
              </div>

              {/* Action/Support Button */}
              <a
                href={supportUrl}
                target="_blank"
                rel="noreferrer noopener"
                className="w-full mt-6 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-3 transition-all active:scale-[0.98] cursor-pointer text-xs uppercase tracking-widest hover:border-[#00FFFF]/30 hover:shadow-[0_0_15px_rgba(0,255,255,0.1)]"
              >
                <Video className="w-4 h-4 text-[#00FFFF]" />
                <span>Hablar con Soporte PinPro</span>
              </a>

            </div>
          </motion.div>
        </div>

        {/* Footer security labels */}
        <div className="text-center space-y-2">
          <p className="text-[10px] font-semibold text-white/30 uppercase tracking-widest leading-relaxed px-4">
            Al ser aprobado, recibirás una notificación y el acceso a la consola Pro con el mapa de clientes se desbloqueará de inmediato.
          </p>
          <div className="text-[8px] font-black uppercase tracking-[0.4em] text-[#B026FF]/50 py-2">
            INTEGRIDAD DIGITAL CRÍPTICA SECURE
          </div>
        </div>

      </div>
    </div>
  );
}

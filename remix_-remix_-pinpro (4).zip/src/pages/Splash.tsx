import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Lock, Briefcase, User, Loader2, ArrowLeft, Mail, Sparkles, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import neonMapBg from '../assets/images/neon_city_map_1776719564588.png';
import { motion, AnimatePresence } from 'motion/react';
import { signInWithPopup } from 'firebase/auth';
import { auth, googleProvider, db } from '../firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { LoadingScreen } from '../components/LoadingScreen';

export default function Splash() {
  const navigate = useNavigate();
  const { user, profile, loading: authLoading, isAdmin, isNavigating, setIsNavigating, refreshAdminStatus, handleNavigateWithTelemetry } = useAuth();
  const [showSecretInput, setShowSecretInput] = useState(false);
  const [secretKey, setSecretKey] = useState('');
  const [entryMode, setEntryMode] = useState<'selection' | 'loading'>('selection');
  const [activeRole, setActiveRole] = useState<'Cliente' | 'Profesional' | 'Agente' | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (authLoading || isNavigating) {
    return <LoadingScreen />;
  }

  const handleSecretSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const sanitizedKey = secretKey.replace(/\s+/g, '').toLowerCase();
    if (sanitizedKey === 'clickjobsolution' || sanitizedKey === '11739552') {
      localStorage.setItem('isAdminAuth', 'true');
      refreshAdminStatus();
      handleNavigateWithTelemetry(window.location.pathname, '/admin', navigate);
    } else if (
      sanitizedKey === 'diagnostico' || 
      sanitizedKey === 'diagnóstico' || 
      sanitizedKey === 'nexus' || 
      sanitizedKey === 'debug' || 
      sanitizedKey === 'pinpro'
    ) {
      handleNavigateWithTelemetry(window.location.pathname, '/diagnostico', navigate);
    } else {
      setError('Clave de acceso incorrecta');
      setShowSecretInput(false);
      setSecretKey('');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-full bg-black overflow-hidden relative max-w-md mx-auto border-x border-white/10 px-6">
      <div className="absolute inset-0 bg-cover bg-center opacity-40 pointer-events-none" style={{ backgroundImage: `url(${neonMapBg})` }}></div>
      <div className="absolute inset-0 bg-black/60 pointer-events-none"></div>
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black pointer-events-none"></div>

      <div id="splash_content_container" className="relative z-20 w-full flex flex-col items-center justify-between h-full py-8">
        <motion.div 
          id="splash_branding"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-center mt-8"
        >
          <div className="flex items-center justify-center mb-2">
            <button 
              id="admin_secret_trigger"
              type="button"
              onClick={() => setShowSecretInput(true)}
              className="flex items-center justify-center -space-x-1 focus:outline-none cursor-pointer hover:opacity-90 active:scale-95 transition-all select-none"
            >
              <span className="text-8xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-[#00FFFF] to-[#B026FF] drop-shadow-[0_0_20px_rgba(0,255,255,0.4)]">Pin</span>
              <span className="text-8xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-[#B026FF] to-[#FF00FF] drop-shadow-[0_0_20px_rgba(176,38,255,0.4)]">Pro</span>
            </button>
          </div>
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.4 }}
            className="h-[2px] w-16 bg-gradient-to-r from-[#00FFFF] to-[#FF00FF] mx-auto rounded-full"
          />
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="text-white/60 text-[10px] font-black uppercase tracking-[0.6em] mt-6"
          >
            Servicios Locales en Tiempo Real
          </motion.p>
        </motion.div>

        <div className="flex-1 flex flex-col justify-center items-center w-full px-6 text-center py-6">
          <h2 className="text-xl font-display font-medium text-white/90 mb-2 italic">
            ¿Qué perfil registrarás?
          </h2>
          <p className="text-white/40 text-[11px] font-medium max-w-[280px] mx-auto leading-relaxed mb-8">
            Selecciona tu rol para comenzar el registro vía WhatsApp.
          </p>

          <div className="w-full flex flex-col gap-6 max-w-sm">
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-red-500/10 border border-red-500/20 text-red-400 text-[10px] py-4 px-4 rounded-2xl text-center font-black uppercase tracking-widest mb-2"
              >
                {error}
              </motion.div>
            )}

            <motion.div
              id="selection_step_2"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col gap-4 w-full"
            >
              {/* Profesional Card */}
              <button 
                id="btn_role_profesional"
                type="button"
                onClick={() => {
                  if (isNavigating) return;
                  handleNavigateWithTelemetry(window.location.pathname, '/register', (path: string) => navigate(path, { state: { initialRole: 'Profesional' } }));
                }}
                disabled={!!activeRole || isNavigating}
                className="group relative w-full h-[72px] bg-white/5 border border-white/10 rounded-[21px] overflow-hidden transition-all hover:bg-white/10 active:scale-[0.98] shadow-2xl cursor-pointer text-left"
              >
                <div className="absolute inset-0 flex items-center justify-between px-5 gap-4">
                  <div className="flex flex-col text-left">
                    <span className="text-[#B026FF] font-black text-[7px] uppercase tracking-widest mb-0.5">Quiero Ofrecer Servicios</span>
                    <span className="text-white font-black text-sm italic tracking-tighter uppercase leading-tight">Soy Profesional</span>
                  </div>
                  <div className="w-9 h-9 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(176,38,255,0.2)]">
                     {activeRole === 'Profesional' ? <Loader2 className="w-[18px] h-[18px] animate-spin text-[#B026FF]" /> : <Briefcase className="w-[18px] h-[18px] text-[#B026FF]" />}
                  </div>
                </div>
              </button>

              {/* Cliente Card */}
              <button 
                id="btn_role_cliente"
                type="button"
                onClick={() => {
                  if (isNavigating) return;
                  handleNavigateWithTelemetry(window.location.pathname, '/register', (path: string) => navigate(path, { state: { initialRole: 'Cliente' } }));
                }}
                disabled={!!activeRole || isNavigating}
                className="group relative w-full h-[72px] bg-white/5 border border-white/10 rounded-[21px] overflow-hidden transition-all hover:bg-white/10 active:scale-[0.98] shadow-2xl cursor-pointer text-left"
              >
                <div className="absolute inset-0 flex items-center justify-between px-5 gap-4">
                  <div className="flex flex-col text-left">
                    <span className="text-[#00FFFF] font-black text-[7px] uppercase tracking-widest mb-0.5">Busco Ayuda Rápida</span>
                    <span className="text-white font-black text-sm italic tracking-tighter uppercase leading-tight">Soy Cliente</span>
                  </div>
                  <div className="w-9 h-9 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center shadow-xl">
                     {activeRole === 'Cliente' ? <Loader2 className="w-[18px] h-[18px] animate-spin text-[#00FFFF]" /> : <User className="w-[18px] h-[18px] text-[#00FFFF]" />}
                  </div>
                </div>
              </button>

              {/* Agente PinPro Card */}
              <button 
                id="btn_role_agente"
                type="button"
                onClick={() => {
                  if (isNavigating) return;
                  handleNavigateWithTelemetry(window.location.pathname, '/register', (path: string) => navigate(path, { state: { initialRole: 'Agente' } }));
                }}
                disabled={!!activeRole || isNavigating}
                className="group relative w-full h-[72px] bg-[#00FF5E]/5 border border-[#00FF5E]/20 rounded-[21px] overflow-hidden transition-all hover:bg-[#00FF5E]/10 active:scale-[0.98] shadow-2xl cursor-pointer text-left"
              >
                <div className="absolute inset-0 flex items-center justify-between px-5 gap-4">
                  <div className="flex flex-col text-left">
                    <span className="text-[#00FF5E] font-black text-[7px] uppercase tracking-widest mb-0.5">Socio Estratégico</span>
                    <span className="text-white font-black text-sm italic tracking-tighter uppercase leading-tight">Agente PinPro</span>
                  </div>
                  <div className="w-9 h-9 bg-white/5 border border-white/10 rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(0,255,94,0.2)]">
                     {activeRole === 'Agente' ? <Loader2 className="w-[18px] h-[18px] animate-spin text-[#00FF5E]" /> : <Sparkles className="w-[18px] h-[18px] text-[#00FF5E]" />}
                  </div>
                </div>
              </button>
            </motion.div>
          </div>
        </div>

        {/* Action Section - Bottom info */}
        <div className="w-full flex flex-col items-center pb-8">
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-3">
               <div className="w-2 h-2 rounded-full bg-white/20"></div>
               <span className="text-white/30 text-[10px] font-medium tracking-wide italic">Conexión Segura v2.0</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center w-full px-6 mb-4">
          <p className="text-white text-[8px] font-bold uppercase tracking-[0.8em]">PinPro Digital Evolution • 2026</p>
        </div>
      </div>

      <AnimatePresence>
        {showSecretInput && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed inset-x-0 bottom-0 p-8 z-50 bg-black/90 backdrop-blur-3xl border-t border-white/5 max-w-md mx-auto"
          >
            <form onSubmit={handleSecretSubmit} className="flex flex-col gap-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white font-black text-[10px] uppercase tracking-widest italic">Panel de Control</span>
                <button type="button" onClick={() => setShowSecretInput(false)} className="text-white/40 hover:text-white flex items-center justify-center p-1" aria-label="Cerrar">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <input
                type="password"
                value={secretKey}
                onChange={(e) => setSecretKey(e.target.value)}
                placeholder="Introducir código..."
                className="w-full bg-white/5 border border-white/10 text-white rounded-2xl py-4 px-6 focus:outline-none focus:border-[#00FFFF] transition-all text-xl font-mono tracking-widest text-center"
                autoFocus
              />
              <button 
                type="submit"
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#00FFFF] to-[#B026FF] text-white font-black uppercase tracking-widest shadow-[0_0_20px_rgba(0,255,255,0.3)]"
              >
                AUTENTICAR
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

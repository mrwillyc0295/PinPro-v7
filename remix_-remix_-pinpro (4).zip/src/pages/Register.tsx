import { signOut } from "firebase/auth";
import {
  User,
  Briefcase,
  ArrowRight,
  Sparkles,
  Mail,
  Lock,
  User as UserIcon,
  Phone,
  Ticket,
  Camera,
  Upload,
  Loader2,
  Globe,
  MapPin,
  CheckCircle,
  X,
} from "lucide-react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import React, { useState, useEffect, useRef } from "react";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { auth, db, storage } from "../firebase";
import { spanishSpeakingCountriesMenu } from "../constants/countries";
// Add custom style to hide country names
const customStyles = `
  .country-name { display: none !important; }
`;
import {
  createUserWithEmailAndPassword,
  signInAnonymously,
} from "firebase/auth";
import {
  doc,
  setDoc,
  getDoc,
  deleteDoc,
  serverTimestamp,
  query,
  collection,
  where,
  getDocs,
} from "firebase/firestore";
import { ref, uploadString, getDownloadURL } from "firebase/storage";
import { useAuth } from "../contexts/AuthContext";
import { serviceCategories } from "../constants/serviceCategories";
import {
  handleFirestoreError,
  OperationType,
} from "../lib/firestoreErrorHandler";
import { cn } from "../lib/utils";
import { Share2 as ShareIcon } from "lucide-react";

const resizeImage = (
  file: File,
  maxWidth: number,
  maxHeight: number,
): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height *= maxWidth / width;
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width *= maxHeight / height;
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", 0.7));
      };
      img.onerror = (error) => reject(error);
    };
    reader.onerror = (error) => reject(error);
  });
};

import neonMapBg from "../assets/images/neon_city_map_1776719564588.png";

export default function Register() {
  const navigate = useNavigate();
  const routerLocation = useLocation();
  const initialRole = (routerLocation.state as any)?.initialRole;
  const {
    user: currentUser,
    profile,
    loading: authLoading,
    isAdmin,
    isNavigating,
    setIsNavigating,
    refreshAdminStatus,
    handleNavigateWithTelemetry,
  } = useAuth();
  const [role, setRole] = useState<
    "Cliente" | "Profesional" | "Referidor" | "Agente"
  >(initialRole || "Cliente");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [appliedReferralCode, setAppliedReferralCode] = useState("");
  const [isReferralValid, setIsReferralValid] = useState<boolean | null>(null);
  const [isCheckingReferral, setIsCheckingReferral] = useState(false);
  const referralTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [profession, setProfession] = useState("");
  const [activities, setActivities] = useState<string[]>([]);
  const [profileImage, setProfileImage] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | React.ReactNode>("");
  const [showSecretInput, setShowSecretInput] = useState(false);
  const [secretKey, setSecretKey] = useState("");

  const [latitude, setLatitude] = useState<number | null>(null);
  const [longitude, setLongitude] = useState<number | null>(null);
  const [country, setCountry] = useState("");
  const [state, setState] = useState("");
  const [municipality, setMunicipality] = useState("");
  const [adminType1, setAdminType1] = useState("Estado");
  const [adminType2, setAdminType2] = useState("Municipio");

  const checkReferralRealTime = async (code: string) => {
    if (!code) {
      setIsReferralValid(null);
      return;
    }

    setIsCheckingReferral(true);
    try {
      const isValid = await validateReferralCode(code);
      setIsReferralValid(isValid);
    } catch (err) {
      console.error("Error validating referral code:", err);
      setIsReferralValid(false);
    } finally {
      setIsCheckingReferral(false);
    }
  };

  useEffect(() => {
    if (referralTimeoutRef.current) {
      clearTimeout(referralTimeoutRef.current);
    }

    if (appliedReferralCode) {
      referralTimeoutRef.current = setTimeout(() => {
        checkReferralRealTime(appliedReferralCode);
      }, 600); // 600ms debounce
    } else {
      setIsReferralValid(null);
    }

    return () => {
      if (referralTimeoutRef.current) {
        clearTimeout(referralTimeoutRef.current);
      }
    };
  }, [appliedReferralCode]);
  const handleCountryChange = (countryLabel: string) => {
    setCountry(countryLabel);
    setState("");
    setMunicipality("");
    const countryData = spanishSpeakingCountriesMenu.find(
      (c) => c.labelCountry === countryLabel,
    );
    if (countryData) {
      setAdminType1(countryData.adminType1);
      setAdminType2(countryData.adminType2);
    }
  };

  const handleStateChange = (stateName: string) => {
    setState(stateName);
    setMunicipality("");
  };

  useEffect(() => {
    // Inject custom styles
    const style = document.createElement("style");
    style.innerHTML = customStyles;
    document.head.appendChild(style);
    return () => {
      document.head.removeChild(style);
    };
  }, []);

  useEffect(() => {
    // AuthGuard (requireAuth={false}) handles redirection for authenticated users.
  }, []);

  const handleSecretSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const sanitizedKey = secretKey.replace(/\s+/g, "");
    if (sanitizedKey === "11739552" || sanitizedKey === "clickjobsolution") {
      localStorage.setItem("isAdminAuth", "true");
      refreshAdminStatus();
      handleNavigateWithTelemetry(routerLocation.pathname, "/admin", navigate);
    } else {
      setError("Clave incorrecta");
      setShowSecretInput(false);
      setSecretKey("");
    }
  };

  const getCollectionName = (selectedRole: string) => {
    if (selectedRole === "Cliente") return "clientes";
    if (selectedRole === "Profesional") return "profesionales";
    if (selectedRole === "Referidor") return "referidores";
    if (selectedRole === "Agente") return "agentes";
    return "clientes";
  };

  const validateReferralCode = async (code: string) => {
    if (!code) return true;
    const formattedCode = code.trim().toUpperCase();

    // Check all user collections for the referral code in parallel for efficiency
    const collections = ["clientes", "profesionales", "referidores", "agentes"];

    try {
      const results = await Promise.all(
        collections.map((coll) =>
          getDocs(
            query(
              collection(db, coll),
              where("referralCode", "==", formattedCode),
            ),
          ),
        ),
      );

      return results.some((snapshot) => !snapshot.empty);
    } catch (err) {
      console.error("[Register] Error validating referral code:", err);
      // If there's a connection error, we log it and continue
      return false;
    }
  };

  const handleLeadCapture = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      setError("Por favor, ingresa tu nombre y número de WhatsApp.");
      return;
    }

    try {
      setLoading(true);
      setError("");

      const leadId = `lead_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      const path = `whatsapp_contacts/${leadId}`;
      try {
        await setDoc(doc(db, "whatsapp_contacts", leadId), {
          name: name.trim(),
          phone: phone.trim(),
          role: role,
          type: "lead",
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }

      setSuccess(true);
      setTimeout(() => setSuccess(false), 5000);
    } catch (err: any) {
      console.error("Error saving lead:", err);
      setError("Error al guardar tus datos. Por favor, inténtalo de nuevo.");
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setLoading(true);
      const base64Image = await resizeImage(file, 800, 800);
      setProfileImage(base64Image);
    } catch (error) {
      console.error("Error resizing image:", String(error));
      setError("Hubo un error al procesar la imagen.");
    } finally {
      setLoading(false);
    }
  };

  const validateEmailForm = () => {
    if (!name.trim()) {
      setError("Por favor, ingresa tu nombre completo.");
      return false;
    }
    if (name.trim().length < 3) {
      setError("El nombre debe tener al menos 3 caracteres.");
      return false;
    }
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Por favor, ingresa un correo electrónico válido.");
      return false;
    }
    if (!password.trim() || password.length < 6) {
      setError("La contraseña debe tener al menos 6 caracteres.");
      return false;
    }
    if (!phone || phone.length < 10) {
      setError("Por favor, ingresa un número de teléfono de WhatsApp válido.");
      return false;
    }
    if (!country) {
      setError("Por favor, selecciona tu país.");
      return false;
    }
    if (!state) {
      setError(`Por favor, selecciona tu ${adminType1}.`);
      return false;
    }
    if (!municipality) {
      setError(`Por favor, selecciona tu ${adminType2}.`);
      return false;
    }
    return true;
  };

  const handleEmailRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!name.trim()) {
      setError("Por favor, ingresa tu nombre completo.");
      return;
    }
    if (!phone || phone.length < 10) {
      setError("Por favor, ingresa un número de WhatsApp válido.");
      return;
    }

    if (role !== "Profesional") {
      if (!country || !state || !municipality) {
        setError("Por favor, completa tu ubicación (País, Estado/Provincia y Municipio).");
        return;
      }
    }

    if (
      appliedReferralCode &&
      !(await validateReferralCode(appliedReferralCode))
    ) {
      setError("El código de referido ingresado no es válido.");
      return;
    }

    try {
      setLoading(true);

      const generatedEmail = `${phone.replace(/\+/g, "")}@pinpro.app`;
      const generatedPassword = `pinpro_${phone.slice(-6)}`;

      let user: any = null;

      try {
        const result = await createUserWithEmailAndPassword(
          auth,
          generatedEmail,
          generatedPassword,
        );
        user = result.user;
      } catch (authErr: any) {
        if (authErr.code === "auth/email-already-in-use") {
          setError("Este número ya está registrado. Por favor, contacta a soporte o intenta con otro.");
          setLoading(false);
          return;
        }
        
        const result = await signInAnonymously(auth);
        user = result.user;
      }

      const collectionName = getCollectionName(role);

      if (role === "Profesional") {
        const userProfile = {
          userId: user.uid,
          uid: user.uid,
          email: generatedEmail,
          fullName: name.trim(),
          name: name.trim(),
          isOnline: false,
          verified: false,
          auditionStatus: "incomplete",
          role: "Profesional",
          status: "Activo",
          phone: phone.startsWith("+") ? phone : `+${phone}`,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          referralCode: `REF-${user.uid.substring(0, 8).toUpperCase()}`,
          referredBy: appliedReferralCode.trim().toUpperCase() || null,
        };
        await setDoc(doc(db, "profesionales", user.uid), userProfile);
      } else {
        const userProfile = {
          uid: user.uid,
          name: name.trim(),
          fullName: name.trim(),
          email: generatedEmail,
          phone: phone.startsWith("+") ? phone : `+${phone}`,
          role: role,
          status: "Activo",
          country: country,
          state: state,
          municipality: municipality,
          latitude: latitude,
          longitude: longitude,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          referralCode: `REF-${user.uid.substring(0, 8).toUpperCase()}`,
          referredBy: appliedReferralCode.trim().toUpperCase() || null,
        };
        await setDoc(doc(db, collectionName, user.uid), userProfile);
      }

      await setDoc(doc(db, "whatsapp_contacts", user.uid), {
        uid: user.uid,
        name: name.trim(),
        phone: phone.trim(),
        role: role,
        email: generatedEmail,
        createdAt: serverTimestamp(),
      });

      handleNavigateWithTelemetry(routerLocation.pathname, "/home", navigate);
    } catch (err: any) {
      console.error("Error en el registro:", err);
      setError(`Error al registrarse: ${err.message || "Inténtalo de nuevo"}`);
    } finally {
      setLoading(false);
    }
  };

  const [step, setStep] = useState(initialRole ? 2 : 1);

  // ... (inside the component return)
  return (
    <div className="relative flex h-full w-full flex-col bg-black overflow-hidden max-w-xl mx-auto">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-50"
        style={{ backgroundImage: `url(${neonMapBg})` }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/90 to-black/40"></div>

      {/* Background Effects */}
      <div className="absolute top-0 left-0 w-full h-64 bg-primary-container/10 blur-[100px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-primary-container/5 blur-[100px] rounded-full pointer-events-none"></div>

      <div className="flex-1 flex flex-col overflow-y-auto hide-scrollbar px-0 pt-12 pb-8 z-10">
        {/* Header */}
        <div className="mb-10 text-center flex flex-col items-center">
          <div className="flex flex-col items-center justify-center mb-8">
            <div className="flex items-center gap-1">
              <span
                className="text-8xl font-black tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-[#00FFFF] to-[#B026FF] drop-shadow-[0_0_15px_rgba(0,255,255,0.5)]"
                style={{
                  fontFamily: "system-ui, sans-serif",
                  WebkitTextStroke: "2px rgba(0,255,255,0.2)",
                }}
              >
                Pin
              </span>
              <span
                className="text-8xl font-black tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-[#B026FF] to-[#FF00FF] drop-shadow-[0_0_15px_rgba(176,38,255,0.5)]"
                style={{
                  fontFamily: "system-ui, sans-serif",
                  WebkitTextStroke: "2px rgba(176,38,255,0.2)",
                }}
              >
                Pro
              </span>
            </div>
          </div>
          {step === 2 && (
            <h1 className="text-2xl font-black text-on-surface mb-2 tracking-tight">
              Crea tu cuenta
            </h1>
          )}
          {step === 2 && (
            <p className="text-sm text-on-surface-variant font-medium">
              Completa tu información para comenzar.
            </p>
          )}
        </div>

        {error && (
          <div className="mb-6 text-red-400 text-sm text-center bg-red-500/10 p-3 rounded-lg border border-red-500/20">
            {error}
          </div>
        )}
        {success && (
          <div className="mb-6 text-green-400 text-sm text-center bg-green-500/10 p-3 rounded-lg border border-green-500/20">
            ¡Datos guardados! Nos pondremos en contacto contigo pronto.
          </div>
        )}
        {!authLoading && currentUser && (
          <div className="mb-6 text-center">
            <p className="text-white/60 text-sm mb-2">
              Ya has iniciado sesión como {currentUser.email}.
            </p>
            <button
              onClick={async () => {
                await signOut(auth);
                window.location.reload();
              }}
              className="bg-white/10 hover:bg-white/20 text-[#00FFFF] py-2 px-4 rounded-lg text-sm font-bold transition-all"
            >
              Cerrar Sesión y Registrar otro correo
            </button>
          </div>
        )}

        <div className="flex flex-col gap-6 w-full pb-4 animate-in fade-in slide-in-from-bottom-5 duration-500">
          {step === 1 ? (
            <div className="flex flex-col items-center justify-center w-full gap-8 px-6">
              <div className="text-center">
                <h2 className="text-3xl font-black text-on-surface mb-3 tracking-tight">
                  Únete a PinPro
                </h2>
                <p className="text-sm text-on-surface-variant font-medium">
                  Selecciona tu perfil de usuario para continuar
                </p>
              </div>

              <div className="flex flex-col gap-4 w-full max-w-sm">
                {/* Profesional Card */}
                <button
                  onClick={() => {
                    setRole("Profesional");
                    setStep(2);
                  }}
                  className="group relative w-full h-24 bg-white/5 border border-white/10 rounded-2xl overflow-hidden transition-all hover:bg-white/10 active:scale-[0.98] shadow-2xl"
                >
                  <div className="absolute top-0 right-0 p-4 pt-6">
                    <Briefcase className="w-16 h-16 text-[#B026FF]/10 -rotate-12 group-hover:scale-110 transition-transform" />
                  </div>
                  <div className="absolute inset-0 flex items-center px-6 gap-4">
                    <div className="w-12 h-12 shrink-0 bg-gradient-to-r from-[#B026FF] to-[#7C3AED] rounded-xl flex items-center justify-center text-white shadow-[0_0_20px_rgba(176,38,255,0.4)]">
                      <Briefcase className="w-6 h-6" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[#B026FF] font-black text-[9px] uppercase tracking-widest mb-0.5">
                        Quiero Trabajar
                      </span>
                      <span className="text-white font-black text-lg italic tracking-tighter uppercase leading-tight">
                        Soy Profesional
                      </span>
                    </div>
                  </div>
                </button>

                {/* Cliente Card */}
                <button
                  onClick={() => {
                    setRole("Cliente");
                    setStep(2);
                  }}
                  className="group relative w-full h-24 bg-white/5 border border-white/10 rounded-2xl overflow-hidden transition-all hover:bg-white/10 active:scale-[0.98] shadow-2xl"
                >
                  <div className="absolute top-0 right-0 p-4 pt-6">
                    <User className="w-16 h-16 text-[#00FFFF]/10 rotate-12 group-hover:scale-110 transition-transform" />
                  </div>
                  <div className="absolute inset-0 flex items-center px-6 gap-4">
                    <div className="w-12 h-12 shrink-0 bg-[#00FFFF] rounded-xl flex items-center justify-center text-black shadow-[0_0_20px_rgba(0,255,255,0.4)]">
                      <User className="w-6 h-6" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[#00FFFF] font-black text-[9px] uppercase tracking-widest mb-0.5">
                        Busco Ayuda
                      </span>
                      <span className="text-white font-black text-lg italic tracking-tighter uppercase leading-tight">
                        Soy Cliente
                      </span>
                    </div>
                  </div>
                </button>

                {/* Referidor Card */}
                <button
                  onClick={() => {
                    setRole("Referidor");
                    setStep(2);
                  }}
                  className="group relative w-full h-24 bg-white/5 border border-white/10 rounded-2xl overflow-hidden transition-all hover:bg-white/10 active:scale-[0.98] shadow-2xl"
                >
                  <div className="absolute top-0 right-0 p-4 pt-6">
                    <ShareIcon className="w-16 h-16 text-[#00dc82]/10 rotate-12 group-hover:scale-110 transition-transform" />
                  </div>
                  <div className="absolute inset-0 flex items-center px-6 gap-4">
                    <div className="w-12 h-12 shrink-0 bg-[#00dc82] rounded-xl flex items-center justify-center text-black shadow-[0_0_20px_rgba(0,220,130,0.4)]">
                      <ShareIcon className="w-6 h-6" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[#00dc82] font-black text-[9px] uppercase tracking-widest mb-0.5">
                        Membresías Limitadas
                      </span>
                      <span className="text-white font-black text-lg italic tracking-tighter uppercase leading-tight">
                        Trabajar como Referidor
                      </span>
                    </div>
                  </div>
                </button>

                {/* CEO MASTER Card */}
                <button
                  type="button"
                  onClick={() => {
                    setShowSecretInput(true);
                  }}
                  className="group relative w-full h-24 bg-red-500/10 border border-red-500/20 rounded-2xl overflow-hidden transition-all hover:bg-red-500/20 active:scale-[0.98] shadow-2xl"
                >
                  <div className="absolute top-0 right-0 p-4 pt-6">
                    <Lock className="w-16 h-16 text-red-500/10 -rotate-12 group-hover:scale-110 transition-transform" />
                  </div>
                  <div className="absolute inset-0 flex items-center px-6 gap-4">
                    <div className="w-12 h-12 shrink-0 bg-red-500 rounded-xl flex items-center justify-center text-white shadow-[0_0_20px_rgba(239,68,68,0.4)]">
                      <Lock className="w-6 h-6" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-red-500 font-black text-[9px] uppercase tracking-widest mb-0.5">
                        Control de Plataforma
                      </span>
                      <span className="text-white font-black text-lg italic tracking-tighter uppercase leading-tight">
                        CEO MASTER
                      </span>
                    </div>
                  </div>
                </button>

                {/* Agente Card */}
                <button
                  onClick={() => {
                    setRole("Agente");
                    setStep(2);
                  }}
                  className="group relative w-full h-24 bg-white/5 border border-white/10 rounded-2xl overflow-hidden transition-all hover:bg-white/10 active:scale-[0.98] shadow-2xl"
                >
                  <div className="absolute top-0 right-0 p-4 pt-6">
                    <Sparkles className="w-16 h-16 text-[#FFD700]/10 -rotate-12 group-hover:scale-110 transition-transform" />
                  </div>
                  <div className="absolute inset-0 flex items-center px-6 gap-4">
                    <div className="w-12 h-12 shrink-0 bg-[#FFD700] rounded-xl flex items-center justify-center text-black shadow-[0_0_20px_rgba(255,215,0,0.4)]">
                      <Sparkles className="w-6 h-6" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span className="text-[#FFD700] font-black text-[9px] uppercase tracking-widest mb-0.5">
                        PinPro Exclusive
                      </span>
                      <span className="text-white font-black text-lg italic tracking-tighter uppercase leading-tight">
                        AGENTE PINPRO
                      </span>
                    </div>
                  </div>
                </button>
              </div>

              <div className="mt-2 flex justify-center">
                <button
                  type="button"
                  onClick={() =>
                    handleNavigateWithTelemetry(
                      routerLocation.pathname,
                      "/inicio-registro",
                      navigate,
                    )
                  }
                  className="py-2 text-[10px] font-black uppercase tracking-widest text-white/40 underline transition-colors hover:text-white cursor-pointer"
                >
                  Volver al Inicio
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Role Indicator */}
              <div className="flex justify-center mb-6">
                <div className="bg-white/5 border border-white/10 px-4 py-2 rounded-full flex items-center gap-2">
                  {role === "Profesional" && (
                    <Briefcase className="w-4 h-4 text-[#B026FF]" />
                  )}
                  {role === "Cliente" && (
                    <User className="w-4 h-4 text-[#00FFFF]" />
                  )}
                  {role === "Referidor" && (
                    <ShareIcon className="w-4 h-4 text-[#00dc82]" />
                  )}
                  {role === "Agente" && (
                    <Sparkles className="w-4 h-4 text-[#FFD700]" />
                  )}
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/60">
                    Perfil: {role}
                  </span>
                </div>
              </div>

              <form
                onSubmit={handleEmailRegister}
                className="flex flex-col gap-5 px-6 md:px-10"
              >
                <div className="flex flex-col gap-4">
                  <div className="relative">
                    <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/30 z-10" />
                    <input
                      id="nombre_completo"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={
                        role === "Cliente"
                          ? "Tu Nombre Completo"
                          : role === "Profesional"
                            ? "Nombre Completo del Profesional"
                            : role === "Referidor"
                              ? "Nombre Completo del Referidor"
                              : "Nombre Completo del Agente"
                      }
                      className={cn(
                        "w-full bg-white/5 border border-white/10 text-white text-sm text-center rounded-2xl h-[56px] px-12 focus:outline-none transition-all",
                        role === "Profesional"
                          ? "focus:border-[#B026FF]"
                          : role === "Referidor"
                            ? "focus:border-[#00dc82]"
                            : role === "Agente"
                              ? "focus:border-[#FFD700]"
                              : "focus:border-[#00FFFF]",
                      )}
                    />
                  </div>

                  <div className="relative">
                    <PhoneInput
                      country={"do"}
                      onlyCountries={[
                        "ar",
                        "bo",
                        "cl",
                        "co",
                        "cr",
                        "cu",
                        "do",
                        "ec",
                        "es",
                        "gq",
                        "gt",
                        "hn",
                        "mx",
                        "ni",
                        "pa",
                        "pe",
                        "pr",
                        "py",
                        "sv",
                        "uy",
                        "ve",
                      ]}
                      value={phone}
                      onChange={setPhone}
                      inputClass="!w-full !bg-transparent !border-0 !text-white !text-sm !text-center !h-[56px] !px-[48px] !m-0"
                      containerClass="!w-full !bg-white/5 !border !border-white/10 !rounded-2xl !h-[56px]"
                      buttonClass="!bg-transparent !border-0 !border-r !border-white/10 !left-0 !rounded-l-2xl !h-[56px] !z-10"
                      dropdownClass="!bg-black !text-white !border-white/10 !rounded-xl"
                      placeholder="WhatsApp"
                    />
                  </div>

                  {role === "Cliente" && (
                    <div className="relative">
                      <Sparkles className="absolute left-4 top-4 w-5 h-5 text-[#00FFFF] z-10" />
                      <textarea
                        value={profession}
                        onChange={(e) => setProfession(e.target.value)}
                        placeholder="¿Qué servicio profesional necesitas?"
                        className="w-full bg-white/5 border border-white/10 text-white text-sm text-center rounded-2xl py-4 px-12 focus:outline-none focus:border-[#00FFFF] transition-all min-h-[100px]"
                      />
                    </div>
                  )}

                  {/* Render location selection ONLY for roles other than Profesional in Phase 1 */}
                  {role !== "Profesional" && (
                    <div className="space-y-4">
                      {/* Location Selection */}
                      <div className="grid grid-cols-1 gap-4">
                        <div className="relative">
                          <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/30 z-10" />
                          <select
                            value={country}
                            onChange={(e) => handleCountryChange(e.target.value)}
                            className="w-full bg-white/5 border border-white/10 text-white text-sm text-center rounded-2xl h-[56px] px-12 focus:outline-none focus:border-[#00FFFF] transition-all appearance-none"
                          >
                            <option value="">Selecciona tu país</option>
                            {spanishSpeakingCountriesMenu.map((c) => (
                              <option
                                key={c.country}
                                value={c.labelCountry}
                                className="bg-black text-white"
                              >
                                {c.labelCountry}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="relative">
                            <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30 z-10" />
                            <select
                              value={state}
                              onChange={(e) => handleStateChange(e.target.value)}
                              disabled={!country}
                              className="w-full bg-white/5 border border-white/10 text-white rounded-2xl h-[56px] px-10 text-center focus:outline-none focus:border-[#00FFFF] transition-all appearance-none disabled:opacity-50 text-sm"
                            >
                              <option value="">{adminType1}</option>
                              {country &&
                                spanishSpeakingCountriesMenu
                                  .find((c) => c.labelCountry === country)
                                  ?.children.map((s) => (
                                    <option
                                      key={s.name}
                                      value={s.name}
                                      className="bg-black text-white"
                                    >
                                      {s.name}
                                    </option>
                                  ))}
                            </select>
                          </div>

                          <div className="relative">
                            <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30 z-10" />
                            <select
                              value={municipality}
                              onChange={(e) => setMunicipality(e.target.value)}
                              disabled={!state}
                              className="w-full bg-white/5 border border-white/10 text-white rounded-2xl h-[56px] px-10 text-center focus:outline-none focus:border-[#00FFFF] transition-all appearance-none disabled:opacity-50 text-sm"
                            >
                              <option value="">{adminType2}</option>
                              {state &&
                                spanishSpeakingCountriesMenu
                                  .find((c) => c.labelCountry === country)
                                  ?.children.find((s) => s.name === state)
                                  ?.children?.map((m) => (
                                    <option
                                      key={m.name}
                                      value={m.name}
                                      className="bg-black text-white"
                                    >
                                      {m.name}
                                    </option>
                                  ))}
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Referral Code Field */}
                  {role !== "Agente" && (
                    <div className="relative">
                      <Ticket className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/30 z-10" />
                      <input
                        type="text"
                        value={appliedReferralCode}
                        onChange={(e) =>
                          setAppliedReferralCode(e.target.value.toUpperCase())
                        }
                        placeholder="CÓDIGO DE REFERIDO (OPCIONAL)"
                        className={cn(
                          "w-full bg-white/5 border rounded-2xl h-[56px] px-12 text-center focus:outline-none transition-all uppercase tracking-widest text-xs",
                          appliedReferralCode
                            ? isCheckingReferral
                              ? "border-blue-500/50"
                              : isReferralValid
                                ? "border-green-500/50 shadow-[0_0_10px_rgba(34,197,94,0.2)]"
                                : "border-red-500/50 shadow-[0_0_10px_rgba(239,68,68,0.2)]"
                            : "border-white/10 focus:border-[#00FFFF]",
                        )}
                      />
                      <div className="absolute right-4 top-1/2 -translate-y-1/2 z-10">
                        {isCheckingReferral && (
                          <Loader2 className="w-5 h-5 animate-spin text-blue-500" />
                        )}
                        {!isCheckingReferral &&
                          appliedReferralCode &&
                          isReferralValid === true && (
                            <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                              <CheckCircle className="w-3 h-3 text-black" />
                            </div>
                          )}
                        {!isCheckingReferral &&
                          appliedReferralCode &&
                          isReferralValid === false && (
                            <X className="w-5 h-5 text-red-500" />
                          )}
                      </div>
                      {appliedReferralCode &&
                        !isCheckingReferral &&
                        isReferralValid === false && (
                          <p className="absolute -bottom-5 left-4 text-[10px] text-red-400 font-bold uppercase">
                            Código no válido
                          </p>
                        )}
                      {appliedReferralCode &&
                        !isCheckingReferral &&
                        isReferralValid === true && (
                          <p className="absolute -bottom-5 left-4 text-[10px] text-green-400 font-bold uppercase">
                            Código válido
                          </p>
                        )}
                    </div>
                  )}
                </div>

                <div className="mt-4 flex flex-col gap-4">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-[#00FFFF] to-[#B026FF] py-4 rounded-2xl text-white font-black uppercase tracking-widest shadow-[0_0_20px_rgba(0,255,255,0.2)] hover:shadow-[0_0_30px_rgba(0,255,255,0.4)] transition-all active:scale-[0.98] disabled:opacity-50"
                  >
                    <span className="flex items-center justify-center gap-2">
                      {loading ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <ArrowRight className="w-5 h-5" />
                      )}
                      {loading ? "PROCESANDO..." : "CREAR MI CUENTA"}
                    </span>
                  </button>
                </div>

                <div className="flex justify-center mt-6">
                  <button
                    type="button"
                    onClick={() => {
                      if (initialRole) {
                        handleNavigateWithTelemetry(
                          routerLocation.pathname,
                          "/inicio-registro",
                          navigate,
                        );
                      } else {
                        setStep(1);
                      }
                    }}
                    className="text-white/40 text-[10px] font-black uppercase tracking-widest hover:text-white underline transition-colors cursor-pointer"
                  >
                    Volver Atrás
                  </button>
                </div>
              </form>
            </>
          )}

          {/* Secret Admin Access */}
          {showSecretInput ? (
            <form
              onSubmit={handleSecretSubmit}
              className="mt-4 w-full animate-in fade-in zoom-in duration-300"
            >
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#00FFFF]" />
                <input
                  type="password"
                  value={secretKey}
                  onChange={(e) => setSecretKey(e.target.value)}
                  placeholder="PIN Administrativo..."
                  className="w-full bg-black/80 border border-[#00FFFF]/30 text-white rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-[#00FFFF] focus:ring-1 focus:ring-[#00FFFF] backdrop-blur-md text-sm"
                  autoFocus
                />
              </div>
              <div className="flex gap-2 mt-2">
                <button
                  type="button"
                  onClick={() => setShowSecretInput(false)}
                  className="flex-1 py-2 rounded-lg border border-white/20 text-white/70 text-sm font-bold hover:bg-white/5 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-lg bg-gradient-to-r from-[#00FFFF] to-[#B026FF] text-white text-sm font-bold shadow-[0_0_10px_rgba(0,255,255,0.3)]"
                >
                  Entrar
                </button>
              </div>
            </form>
          ) : (
            <div className="flex justify-center mt-2">
              <button
                onClick={() => setShowSecretInput(true)}
                className="w-10 h-10 rounded-full opacity-20 hover:opacity-100 focus:opacity-100 transition-opacity flex items-center justify-center cursor-default"
                aria-label="Acceso Administrativo"
              >
                <div className="w-1.5 h-1.5 rounded-full bg-white/20"></div>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

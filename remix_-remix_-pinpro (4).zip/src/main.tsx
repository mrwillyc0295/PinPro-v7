import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';

// Bypass permissions and mockup geolocation/media streams during testing or constrained container contexts
if (typeof window !== "undefined") {
  // Mock Geolocation specifically with PinPro default coordinates
  const defaultCoords = {
    latitude: -12.046374,
    longitude: -77.042793,
    accuracy: 10,
    altitude: null,
    altitudeAccuracy: null,
    heading: null,
    speed: null,
  };

  const mockGeolocation = {
    getCurrentPosition: (successCallback: any, errorCallback?: any) => {
      setTimeout(() => {
        try {
          successCallback({
            coords: defaultCoords,
            timestamp: Date.now()
          });
        } catch (e) {
          if (errorCallback) errorCallback(e);
        }
      }, 50);
    },
    watchPosition: (successCallback: any, errorCallback?: any) => {
      const interval = setInterval(() => {
        try {
          successCallback({
            coords: defaultCoords,
            timestamp: Date.now()
          });
        } catch (e) {
          if (errorCallback) errorCallback(e);
        }
      }, 1000);
      return interval as any;
    },
    clearWatch: (watchId: any) => {
      clearInterval(watchId);
    }
  };

  // Enforce bypass of geolocation prompts
  try {
    Object.defineProperty(navigator, 'geolocation', {
      value: mockGeolocation,
      configurable: true,
      writable: true
    });
  } catch (e) {
    console.warn("Could not mock geolocation:", e);
  }

  // Mock microphone and camera media streams for voice/interactive calls in test environments
  if (navigator.mediaDevices) {
    const originalGetUserMedia = navigator.mediaDevices.getUserMedia?.bind(navigator.mediaDevices);
    navigator.mediaDevices.getUserMedia = async (constraints) => {
      try {
        if (originalGetUserMedia) {
          return await originalGetUserMedia(constraints);
        }
      } catch (err) {
        console.warn("Bypassing media permissions constraints with test audio-track stream", err);
      }
      
      // Fallback: build a mock/silent media stream
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const dst = oscillator.connect(audioContext.createMediaStreamDestination()) as any;
      oscillator.start();
      return dst.stream;
    };
  }
}

import App from './App.tsx';
import ErrorBoundary from './components/ErrorBoundary';
import './index.css';
import './i18n';
import './lib/mapFix'; // Patch Leaflet
import { HelmetProvider } from 'react-helmet-async';

// Register Service Worker for PWA (defensively)
try {
  import('virtual:pwa-register').then(({ registerSW }) => {
    if ('serviceWorker' in navigator) {
      registerSW({ immediate: true });
    }
  }).catch(err => {
    console.warn("PWA register skipped in dev/preview:", err);
  });
} catch (e) {
  console.warn("Error importing PWA module", e);
}

// Ocultar el app-shell visual al montar React
const renderApp = () => {
  try {
    const rootElement = document.getElementById('root')!;
    
    createRoot(rootElement).render(
      <ErrorBoundary>
        <HelmetProvider>
          <App />
        </HelmetProvider>
      </ErrorBoundary>
    );
  } catch (err) {
    console.error("Critical error mounting React App:", err);
    // Optionally fallback if React completely fails to mount
    document.body.innerHTML = `<div style="color:white; padding: 20px;">Critical start error: ${err}</div>`;
  }
};

renderApp();

// Manual Service Worker registration for FCM Push Notifications support
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/firebase-messaging-sw.js')
      .then(registration => {
        console.log('FCM Service Worker registered successfully');
      })
      .catch(error => {
        console.error('FCM Service Worker registration failed:', error);
      });
  });
}

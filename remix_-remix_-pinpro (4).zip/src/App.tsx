/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import './lib/mapFix';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import ErrorBoundary from './components/ErrorBoundary';
import GlobalLoader from './components/GlobalLoader';
import Layout from './components/Layout';
import React, { useState, useEffect, lazy, Suspense } from 'react';

// Lazy load pages
import Home from './pages/Home';
const Profile = lazy(() => import('./pages/Profile'));
const Wallet = lazy(() => import('./pages/Wallet'));
const Messages = lazy(() => import('./pages/Messages'));
const ChatDetail = lazy(() => import('./pages/ChatDetail'));
const NewRequest = lazy(() => import('./pages/NewRequest'));
const Booking = lazy(() => import('./pages/Booking'));
const Notifications = lazy(() => import('./pages/Notifications'));
const Activity = lazy(() => import('./pages/Activity'));
const Settings = lazy(() => import('./pages/Settings'));
const Register = lazy(() => import('./pages/Register'));
const Referrals = lazy(() => import('./pages/Referrals'));
const Premium = lazy(() => import('./pages/Premium'));
const EditProfile = lazy(() => import('./pages/EditProfile'));
const PublicProfile = lazy(() => import('./pages/PublicProfile'));
const PrivacyPolicy = lazy(() => import('./pages/PrivacyPolicy'));
const About = lazy(() => import('./pages/About'));
const Security = lazy(() => import('./pages/Security'));
const PaymentMethods = lazy(() => import('./pages/PaymentMethods'));
const CashOut = lazy(() => import('./pages/CashOut'));
const TermsAndConditions = lazy(() => import('./pages/TermsAndConditions'));
const Splash = lazy(() => import('./pages/Splash'));
const CompleteProfile = lazy(() => import('./pages/CompleteProfile'));
const AudicionRevision = lazy(() => import('./pages/AudicionRevision'));
const PremiumFilter = lazy(() => import('./pages/PremiumFilter'));
const AdminDashboard = lazy(() => import('./pages/AdminDashboard'));
const AdminReports = lazy(() => import('./pages/AdminReports'));
const AdminAuditions = lazy(() => import('./pages/AdminAuditions'));
const AdminCommunications = lazy(() => import('./pages/AdminCommunications'));
const EmergencyRequest = lazy(() => import('./pages/EmergencyRequest'));
const Tracking = lazy(() => import('./pages/Tracking'));
const TrackingEmergency = lazy(() => import('./pages/TrackingEmergency'));
const ClientReservations = lazy(() => import('./pages/ClientReservations'));
const ClientDashboard = lazy(() => import('./pages/ClientDashboard'));
const ClientSetupProfile = lazy(() => import('./pages/ClientSetupProfile'));
const MuroRequerimientos = lazy(() => import('./pages/MuroRequerimientos'));
const FirebaseDiagnostic = lazy(() => import('./components/FirebaseDiagnostic'));
const AuditReport = lazy(() => import('./pages/AuditReport'));
const ProDashboard = lazy(() => import('./pages/ProDashboard'));
const Users = lazy(() => import('./pages/Users'));
const AirdropRewards = lazy(() => import('./pages/AirdropRewards'));
const ExpertAudition = lazy(() => import('./pages/ExpertAudition'));
const MasterBrainMonitor = lazy(() => import('./pages/MasterBrainMonitor'));
const DashboardReferidor = lazy(() => import('./pages/DashboardReferidor'));
const MapaClientes = lazy(() => import('./pages/MapaClientes'));

import { AdminGuard } from './components/AdminGuard';

import { RoleGuard } from './components/RoleGuard';
import { AuthGuard } from './components/AuthGuard';

import { ViewProvider, useView } from './contexts/ViewContext';
import EmergencyDespatcher from './components/professional/EmergencyDespatcher';
import AvisoInstalacion from './components/AvisoInstalacion';
import { GlobalBackButton } from './components/GlobalBackButton';
import { ProtectedRoute, PublicRoute } from './components/RouteGuards';
import { getMessagingSafe } from './firebase';
import { getToken } from 'firebase/messaging';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from './firebase';

function RootRedirect() {
  const { profile, isAdmin, authState } = useAuth();
  
  if (authState === 'LOADING') {
    return <GlobalLoader />;
  }
  
  const isRealProfile = profile && !(profile as any).isNewUser;
  
  if (authState === 'AUTHENTICATED' && (isRealProfile || isAdmin)) {
    return <Navigate to="/mapa" replace />;
  }
  
  return <Navigate to="/inicio-registro" replace />;
}

function AppContent() {
  const { viewMode } = useView();
  const { user } = useAuth();

  useEffect(() => {
    const solicitarPermisoNotificaciones = async () => {
      if (!user) return;
      
      try {
        const messagingInstance = await getMessagingSafe();
        if (!messagingInstance) return;

        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
          const token = await getToken(messagingInstance, {
            vapidKey: import.meta.env.VITE_VAPID_PUBLIC_KEY
          });

          if (token) {
            console.log('🔥 Device token obtained:', token);
            // Save token to user profile
            await updateDoc(doc(db, 'users', user.uid), {
              fcmToken: token,
              pushNotificationsEnabled: true,
              lastTokenUpdate: new Date().toISOString()
            });
          }
        }
      } catch (error) {
        console.error('❌ Error requesting notifications:', error);
      }
    };

    if (user) {
      solicitarPermisoNotificaciones();
    }
  }, [user]);

  const getContainerWidth = () => {
    return 'w-full';
  };

  return (
    <div className="bg-black min-h-screen w-full overflow-x-hidden">
      <div className={`min-h-screen w-full bg-black relative flex flex-col md:shadow-2xl transition-all duration-700 ease-in-out ${getContainerWidth()}`}>
          <div className="flex-1 flex flex-col relative pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)]">
            <GlobalBackButton />
            <EmergencyDespatcher />
            <Routes>
              {/* Ruta Raíz: decide a dónde mandar al usuario según su sesión */}
              <Route path="/" element={<RootRedirect />} />

              {/* Rutas Públicas: Solo accesibles si NO hay sesión válida */}
              <Route element={<PublicRoute />}>
                <Route path="/inicio-registro" element={<Splash />} />
                <Route path="/register" element={<Register />} />
                <Route path="/welcome" element={<Navigate to="/inicio-registro" replace />} />
              </Route>

              {/* Rutas Protegidas: Solo accesibles si SÍ hay sesión válida */}
              <Route path="/diagnostico" element={<FirebaseDiagnostic />} />
              <Route element={<ProtectedRoute />}>
                <Route path="/complete-profile" element={<CompleteProfile />} />
                <Route path="/audicion-revision" element={<AudicionRevision />} />
                <Route path="/premium-filter" element={<PremiumFilter />} />
                <Route path="/emergency/:id" element={<EmergencyRequest />} />
                <Route path="/tracking/:id" element={<TrackingEmergency />} />
                
                <Route element={<Layout />}>
                  <Route path="/home" element={<Home />} />
                  <Route path="/mapa" element={<Home />} />
                  <Route path="/mapa-clientes" element={<MapaClientes />} />
                  <Route path="/perfil-profesional" element={<Profile />} />
                  <Route path="/dashboard-cliente" element={<RoleGuard allowedRoles={['Cliente']} fallbackPath="/inicio-registro"><ClientDashboard /></RoleGuard>} />
                  
                  <Route 
                    path="/dashboard" 
                    element={
                      <AdminGuard>
                        <AdminDashboard />
                      </AdminGuard>
                    } 
                  />
                  <Route path="/pro/dashboard" element={<RoleGuard allowedRoles={['Profesional']} fallbackPath="/inicio-registro"><ProDashboard /></RoleGuard>} />
                  <Route path="/users" element={<Users />} />
                  <Route 
                    path="/admin" 
                    element={
                      <AdminGuard>
                        <AdminDashboard />
                      </AdminGuard>
                    } 
                  />
                  <Route 
                    path="/admin/reports" 
                    element={
                      <AdminGuard>
                        <AdminReports />
                      </AdminGuard>
                    } 
                  />
                  <Route 
                    path="/admin/auditions" 
                    element={
                      <AdminGuard>
                        <AdminAuditions />
                      </AdminGuard>
                    } 
                  />
                  <Route 
                    path="/admin/communications" 
                    element={
                      <AdminGuard>
                        <AdminCommunications />
                      </AdminGuard>
                    } 
                  />
                  <Route 
                    path="/admin/expert-audition" 
                    element={
                      <AdminGuard>
                        <ExpertAudition />
                      </AdminGuard>
                    } 
                  />
                  <Route 
                    path="/admin/masterbrain" 
                    element={
                      <AdminGuard>
                        <MasterBrainMonitor />
                      </AdminGuard>
                    } 
                  />
                  <Route 
                    path="/dashboard-referidor" 
                    element={<DashboardReferidor />} 
                  />
                  <Route path="/profile" element={<Profile />} />
                  <Route path="/profile/cliente" element={<Profile />} />
                  <Route path="/profile/profesional" element={<Profile />} />
                  <Route path="/profile/:id" element={<PublicProfile />} />
                  <Route path="/p/:id" element={<PublicProfile />} />
                  <Route path="edit-profile" element={<EditProfile />} />
                  <Route path="wallet" element={<Wallet />} />
                  <Route path="cash-out" element={<CashOut />} />
                  <Route path="payment-methods" element={<PaymentMethods />} />
                  <Route path="messages" element={<Messages />} />
                  <Route path="messages/:id" element={<ChatDetail />} />
                  <Route path="new-request" element={<RoleGuard allowedRoles={['Cliente']} fallbackPath="/inicio-registro"><NewRequest /></RoleGuard>} />
                  <Route path="booking/:id" element={<Booking />} />
                  <Route path="notifications" element={<Notifications />} />
                  <Route path="activity" element={<Activity />} />
                  <Route path="settings" element={<Settings />} />
                  <Route path="privacy" element={<PrivacyPolicy />} />
                  <Route path="terms" element={<TermsAndConditions />} />
                  <Route path="about" element={<About />} />
                  <Route path="security" element={<Security />} />
                  <Route path="referrals" element={<Referrals />} />
                  <Route path="premium" element={<Premium />} />
                  <Route path="airdrop" element={<RoleGuard allowedRoles={['Profesional']} fallbackPath="/inicio-registro"><AirdropRewards /></RoleGuard>} />
                  <Route path="tracking" element={<Tracking />} />
                  <Route path="client-reservations" element={<ClientReservations />} />
                  <Route path="client/dashboard" element={<RoleGuard allowedRoles={['Cliente']} fallbackPath="/inicio-registro"><ClientDashboard /></RoleGuard>} />
                  <Route path="client/setup" element={<RoleGuard allowedRoles={['Cliente']} fallbackPath="/inicio-registro"><ClientSetupProfile /></RoleGuard>} />
                  <Route path="muro-requerimientos" element={<RoleGuard allowedRoles={['Profesional']} fallbackPath="/inicio-registro"><MuroRequerimientos /></RoleGuard>} />
                  <Route path="audit-report" element={<AuditReport />} />
                </Route>
              </Route>

              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
            <AvisoInstalacion />
        </div>
      </div>
    </div>
  );
}

import { AnalyticsProvider } from './contexts/AnalyticsContext';

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <AnalyticsProvider>
          <AuthProvider>
            <ViewProvider>
              <AppContent />
            </ViewProvider>
          </AuthProvider>
        </AnalyticsProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}

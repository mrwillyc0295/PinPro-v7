importScripts('https://www.gstatic.com/firebasejs/10.7.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.7.0/firebase-messaging-compat.js');

// Configuración básica (Reemplazada en tiempo de ejecución o configurada manualmente)
firebase.initializeApp({
  apiKey: "AIzaSyAUbkjGk0mE26qABQwNtSUX6sYiVmgoXbU",
  authDomain: "pin-pro-v7.firebaseapp.com",
  projectId: "pin-pro-v7",
  storageBucket: "pin-pro-v7.firebasestorage.app",
  messagingSenderId: "982999519082",
  appId: "1:982999519082:web:979a0e56b71a87d6a3df13"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Mensaje recibido en segundo plano ', payload);
  
  const notificationTitle = payload.notification.title || "Nueva alerta PinPro";
  const notificationOptions = {
    body: payload.notification.body,
    icon: '/logo192.png',
    badge: '/favicon.ico'
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
